<!DOCTYPE html>
<html>
<head>
    <title>Test Login</title>
    <style>
        body { font-family: Arial; text-align: center; padding: 50px; }
        .btn { 
            background: #800000; 
            color: white; 
            padding: 15px 30px; 
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin: 10px;
        }
        .btn:hover { background: #600000; }
    </style>
</head>
<body>
    <h1>Test Login Links</h1>
    <a href="login.php" class="btn">Go to login.php (Relative Path)</a><br>
    <a href="/sistem_perpustakaan/login.php" class="btn">Go to login.php (Absolute Path)</a><br>
    <a href="./login.php" class="btn">Go to login.php (Current Directory)</a><br>
    <a href="../sistem_perpustakaan/login.php" class="btn">Go to login.php (Parent Directory)</a>
</body>
</html>