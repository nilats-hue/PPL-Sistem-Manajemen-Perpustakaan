<?php
// debug_login.php
require_once 'koneksi.php';

echo "<h2>Debug Login System</h2>";

// 1. Cek koneksi
echo "<h3>1. Database Connection:</h3>";
echo "Host: localhost<br>";
echo "Database: sistem_perpustakaan<br>";
echo "Status: " . (mysqli_ping($koneksi) ? "Connected" : "Disconnected") . "<br>";

// 2. Cek tabel users
echo "<h3>2. Users Table:</h3>";
$result = mysqli_query($koneksi, "SHOW TABLES LIKE 'users'");
if (mysqli_num_rows($result) > 0) {
    echo "Table 'users' exists.<br>";
    
    // 3. Tampilkan data users
    $users = mysqli_query($koneksi, "SELECT id, username, password, nama, role FROM users");
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Username</th><th>Password</th><th>Nama</th><th>Role</th></tr>";
    while ($row = mysqli_fetch_assoc($users)) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . htmlspecialchars($row['password']) . " (length: " . strlen($row['password']) . ")</td>";
        echo "<td>" . $row['nama'] . "</td>";
        echo "<td>" . $row['role'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Table 'users' does not exist!<br>";
    
    // Buat tabel jika tidak ada
    echo "<h3>Creating users table...</h3>";
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        nama VARCHAR(100) NOT NULL,
        role ENUM('admin', 'pustakawan') DEFAULT 'pustakawan',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (mysqli_query($koneksi, $sql)) {
        echo "Table created successfully!<br>";
        
        // Tambahkan user default
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, password, nama, role) VALUES 
                ('admin', '$hash', 'Administrator', 'admin'),
                ('pustakawan', '$hash', 'Pustakawan', 'pustakawan')";
        
        if (mysqli_query($koneksi, $sql)) {
            echo "Default users added!<br>";
        }
    }
}

// 4. Test password verify
echo "<h3>3. Password Test:</h3>";
$test_pass = 'admin123';
$hash = password_hash($test_pass, PASSWORD_DEFAULT);
echo "Password: $test_pass<br>";
echo "Hash: $hash<br>";
echo "Verify: " . (password_verify($test_pass, $hash) ? "YES" : "NO") . "<br>";

// 5. Test query untuk user 'admin'
echo "<h3>4. Test Query for 'admin':</h3>";
$query = "SELECT * FROM users WHERE username = 'admin'";
$result = mysqli_query($koneksi, $query);
if ($result) {
    $num = mysqli_num_rows($result);
    echo "Found $num user(s) with username 'admin'<br>";
    if ($num > 0) {
        $user = mysqli_fetch_assoc($result);
        echo "User data: " . print_r($user, true) . "<br>";
    }
} else {
    echo "Query error: " . mysqli_error($koneksi) . "<br>";
}
?>