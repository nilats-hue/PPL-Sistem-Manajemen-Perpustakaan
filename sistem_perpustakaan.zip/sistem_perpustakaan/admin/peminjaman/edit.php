<?php
$page_title = "Edit Peminjaman";
$page_subtitle = "Edit data peminjaman";

require_once '../header.php';

// ===============================
// VALIDASI ID
// ===============================
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message("ID peminjaman tidak valid!", 'error');
    redirect('index.php');
}

$id = clean_input($_GET['id']);

// ===============================
// AMBIL DATA PEMINJAMAN
// ===============================
$query = "SELECT p.*, 
                 a.nama AS nama_anggota, a.kode_anggota, 
                 b.judul AS judul_buku, b.isbn, b.stok
          FROM peminjaman p
          JOIN anggota a ON p.anggota_id = a.id
          JOIN buku b ON p.buku_id = b.id
          WHERE p.id = '$id'";

$result = mysqli_query($koneksi, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    set_message("Peminjaman tidak ditemukan!", 'error');
    redirect('index.php');
}

$peminjaman = mysqli_fetch_assoc($result);

// ===============================
// PROSES UPDATE
// ===============================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $tanggal_pinjam   = clean_input($_POST['tanggal_pinjam'] ?? '');
    $batas_kembali    = clean_input($_POST['batas_kembali'] ?? '');
    $tanggal_kembali  = clean_input($_POST['tanggal_kembali'] ?? '');
    $status           = clean_input($_POST['status'] ?? '');
    $denda            = clean_input($_POST['denda'] ?? 0);
    $keterangan       = clean_input($_POST['keterangan'] ?? '');

    $errors = [];

    if ($tanggal_pinjam === '') {
        $errors[] = "Tanggal pinjam wajib diisi!";
    }

    if ($batas_kembali === '') {
        $errors[] = "Batas kembali wajib diisi!";
    }

    if ($status === '') {
        $errors[] = "Status wajib dipilih!";
    }

    if (empty($errors)) {
        // Mulai transaction
        mysqli_begin_transaction($koneksi);
        
        try {
            // Update data peminjaman
            $query_update = "
                UPDATE peminjaman SET 
                    tanggal_pinjam  = '$tanggal_pinjam',
                    batas_kembali   = '$batas_kembali',
                    tanggal_kembali = " . ($tanggal_kembali !== '' ? "'$tanggal_kembali'" : "NULL") . ",
                    status          = '$status',
                    denda           = '$denda',
                    keterangan      = '$keterangan'
                WHERE id = '$id'
            ";

            if (!mysqli_query($koneksi, $query_update)) {
                throw new Exception("Gagal update peminjaman: " . mysqli_error($koneksi));
            }

            // Update status buku berdasarkan status peminjaman
            if ($status === 'selesai' || $status === 'dikembalikan') {
                // Jika selesai, kembalikan stok buku
                $query_update_buku = "UPDATE buku SET 
                    stok = stok + 1,
                    status = 'tersedia' 
                    WHERE id = '{$peminjaman['buku_id']}'";
            } else {
                // Jika masih dipinjam, pastikan stok berkurang
                $query_update_buku = "UPDATE buku SET 
                    status = 'dipinjam' 
                    WHERE id = '{$peminjaman['buku_id']}'";
            }
            
            if (!mysqli_query($koneksi, $query_update_buku)) {
                throw new Exception("Gagal update status buku: " . mysqli_error($koneksi));
            }

            // Commit transaction
            mysqli_commit($koneksi);
            
            set_message("Data peminjaman berhasil diperbarui!", 'success');
            redirect('index.php');
            
        } catch (Exception $e) {
            // Rollback transaction
            mysqli_rollback($koneksi);
            set_message("Gagal memperbarui data: " . $e->getMessage(), 'error');
        }

    } else {
        set_message(implode("<br>", $errors), 'error');
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">

        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-edit me-2"></i> Form Edit Peminjaman
                </h5>
            </div>

            <div class="card-body">
                <form method="POST">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kode Peminjaman</label>
                            <input type="text" class="form-control" readonly
                                   value="<?php echo htmlspecialchars($peminjaman['kode_peminjaman'] ?? '-'); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status <span class="text-danger">*</span></label>
                            <select name="status" class="form-select" required>
                                <option value="diajukan"  <?php echo ($peminjaman['status'] === 'diajukan') ? 'selected' : ''; ?>>Diajukan</option>
                                <option value="disetujui" <?php echo ($peminjaman['status'] === 'disetujui') ? 'selected' : ''; ?>>Disetujui</option>
                                <option value="dipinjam"  <?php echo ($peminjaman['status'] === 'dipinjam') ? 'selected' : ''; ?>>Dipinjam</option>
                                <option value="terlambat" <?php echo ($peminjaman['status'] === 'terlambat') ? 'selected' : ''; ?>>Terlambat</option>
                                <option value="selesai"   <?php echo ($peminjaman['status'] === 'selesai' || $peminjaman['status'] === 'dikembalikan') ? 'selected' : ''; ?>>Selesai/Dikembalikan</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Anggota</label>
                        <input type="text" class="form-control" readonly
                               value="<?php echo htmlspecialchars($peminjaman['nama_anggota'] . ' (' . $peminjaman['kode_anggota'] . ')'); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Buku</label>
                        <input type="text" class="form-control" readonly
                               value="<?php echo htmlspecialchars($peminjaman['judul_buku'] . ' (Stok: ' . $peminjaman['stok'] . ')'); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Tanggal Pinjam <span class="text-danger">*</span></label>
                            <input type="date" name="tanggal_pinjam" class="form-control" required
                                   value="<?php echo htmlspecialchars($_POST['tanggal_pinjam'] ?? ($peminjaman['tanggal_pinjam'] ?? date('Y-m-d'))); ?>">
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Batas Kembali <span class="text-danger">*</span></label>
                            <input type="date" name="batas_kembali" class="form-control" required
                                   value="<?php echo htmlspecialchars($_POST['batas_kembali'] ?? ($peminjaman['batas_kembali'] ?? date('Y-m-d', strtotime('+7 days')))); ?>">
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Tanggal Kembali</label>
                            <input type="date" name="tanggal_kembali" class="form-control"
                                   value="<?php echo htmlspecialchars($_POST['tanggal_kembali'] ?? ($peminjaman['tanggal_kembali'] ?? '')); ?>">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Denda (Rp)</label>
                            <input type="number" name="denda" class="form-control" min="0" step="1000"
                                   value="<?php echo htmlspecialchars($_POST['denda'] ?? ($peminjaman['denda'] ?? 0)); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Input</label>
                            <input type="text" class="form-control" readonly
                                   value="<?php echo date('d/m/Y H:i', strtotime($peminjaman['created_at'] ?? date('Y-m-d H:i:s'))); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Keterangan</label>
                        <textarea name="keterangan" class="form-control" rows="3"><?php
                            echo htmlspecialchars($_POST['keterangan'] ?? ($peminjaman['keterangan'] ?? ''));
                        ?></textarea>
                    </div>

                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Catatan:</strong> Jika status diubah menjadi "Selesai/Dikembalikan", stok buku akan otomatis dikembalikan.
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-maroon me-2">
                            <i class="fas fa-save me-1"></i> Simpan Perubahan
                        </button>

                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i> Batal
                        </a>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../footer.php'; ?>