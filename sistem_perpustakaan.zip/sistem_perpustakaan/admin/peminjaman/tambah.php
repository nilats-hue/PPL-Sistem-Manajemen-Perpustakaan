<?php
ob_start();

$page_title    = "Tambah Peminjaman";
$page_subtitle = "Tambah data peminjaman buku";

require_once '../header.php';

// ===============================
// GENERATE KODE PEMINJAMAN OTOMATIS
// ===============================
function generate_kode_peminjaman($koneksi) {
    // Ambil kode terakhir
    $query = "SELECT kode_peminjaman FROM peminjaman 
              WHERE kode_peminjaman LIKE 'PIN%' 
              ORDER BY id DESC LIMIT 1";
    $result = mysqli_query($koneksi, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $last_kode = $row['kode_peminjaman'];
        // Ambil angka terakhir
        $last_number = (int) substr($last_kode, 3);
        $new_number = $last_number + 1;
        $new_kode = 'PIN' . str_pad($new_number, 4, '0', STR_PAD_LEFT);
    } else {
        // Jika belum ada data, mulai dari PIN0001
        $new_kode = 'PIN0001';
    }
    
    return $new_kode;
}

// ===============================
// AMBIL DATA ANGGOTA & BUKU
// ===============================
$anggota = mysqli_query($koneksi, "SELECT id, kode_anggota, nama FROM anggota WHERE status='aktif' ORDER BY nama");
$buku    = mysqli_query($koneksi, "SELECT id, judul FROM buku ORDER BY judul");

// ===============================
// PROSES TAMBAH DATA
// ===============================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $anggota_id      = clean_input($_POST['anggota_id'] ?? '');
    $buku_id         = clean_input($_POST['buku_id'] ?? '');
    $tanggal_pinjam  = clean_input($_POST['tanggal_pinjam'] ?? '');
    $batas_kembali   = clean_input($_POST['batas_kembali'] ?? '');
    $status          = 'dipinjam';
    $kode_peminjaman = generate_kode_peminjaman($koneksi); // Generate kode otomatis

    $errors = [];

    if ($anggota_id === '') {
        $errors[] = "Anggota wajib dipilih!";
    }

    if ($buku_id === '') {
        $errors[] = "Buku wajib dipilih!";
    }

    if ($tanggal_pinjam === '') {
        $errors[] = "Tanggal pinjam wajib diisi!";
    }

    if ($batas_kembali === '') {
        $errors[] = "Batas kembali wajib diisi!";
    }

    if (empty($errors)) {

        $stmt = mysqli_prepare($koneksi, "
            INSERT INTO peminjaman
            (kode_peminjaman, anggota_id, buku_id, tanggal_pinjam, batas_kembali, status)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                "siisss",
                $kode_peminjaman,
                $anggota_id,
                $buku_id,
                $tanggal_pinjam,
                $batas_kembali,
                $status
            );

            if (mysqli_stmt_execute($stmt)) {
                set_message("Peminjaman berhasil ditambahkan! Kode: $kode_peminjaman", 'success');
                redirect('index.php');
            } else {
                set_message("Gagal menambahkan peminjaman: " . mysqli_error($koneksi), 'error');
            }

            mysqli_stmt_close($stmt);

        } else {
            set_message("Gagal prepare statement!", 'error');
        }

    } else {
        set_message(implode("<br>", $errors), 'error');
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-handshake me-2"></i> Form Tambah Peminjaman
                </h5>
            </div>

            <div class="card-body">
                <form method="POST">

                    <div class="mb-3">
                        <label class="form-label">Kode Peminjaman (Otomatis)</label>
                        <input type="text" class="form-control" readonly
                               value="<?php echo generate_kode_peminjaman($koneksi); ?>">
                        <small class="text-muted">Kode akan di-generate otomatis saat disimpan</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Anggota <span class="text-danger">*</span></label>
                        <select name="anggota_id" class="form-select" required>
                            <option value="">-- Pilih Anggota --</option>
                            <?php while ($a = mysqli_fetch_assoc($anggota)): ?>
                                <option value="<?php echo $a['id']; ?>"
                                    <?php echo ($_POST['anggota_id'] ?? '') == $a['id'] ? 'selected' : ''; ?>>
                                    <?php echo $a['kode_anggota'] . ' - ' . $a['nama']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Buku <span class="text-danger">*</span></label>
                        <select name="buku_id" class="form-select" required>
                            <option value="">-- Pilih Buku --</option>
                            <?php while ($b = mysqli_fetch_assoc($buku)): ?>
                                <option value="<?php echo $b['id']; ?>"
                                    <?php echo ($_POST['buku_id'] ?? '') == $b['id'] ? 'selected' : ''; ?>>
                                    <?php echo $b['judul']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Pinjam <span class="text-danger">*</span></label>
                            <input type="date" name="tanggal_pinjam" class="form-control" required
                                   value="<?php echo htmlspecialchars($_POST['tanggal_pinjam'] ?? date('Y-m-d')); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Batas Kembali <span class="text-danger">*</span></label>
                            <input type="date" name="batas_kembali" class="form-control" required
                                   value="<?php echo htmlspecialchars($_POST['batas_kembali'] ?? date('Y-m-d', strtotime('+7 days'))); ?>">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-maroon me-2">
                            <i class="fas fa-save me-1"></i> Simpan
                        </button>

                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Batal
                        </a>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php
require_once '../footer.php';
ob_end_flush();
?>