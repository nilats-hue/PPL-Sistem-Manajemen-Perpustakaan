<?php
require_once '../../koneksi.php';

// Cegah session_start double
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Fungsi pengganti clean_input()
function clean_input($data, $koneksi) {
    return mysqli_real_escape_string($koneksi, htmlspecialchars(trim($data)));
}

// Cek login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header('Location: ../../login.php');
    exit();
}

// Cek role admin/petugas
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'petugas') {
    $_SESSION['message'] = "Akses ditolak!";
    $_SESSION['message_type'] = "error";
    header("Location: ../../login.php");
    exit();
}

// Validasi id
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['message'] = "ID peminjaman tidak valid!";
    $_SESSION['message_type'] = "error";
    header("Location: index.php");
    exit();
}

$id = clean_input($_GET['id'], $koneksi);

// Cek peminjaman ada atau tidak
$query_check = "SELECT * FROM peminjaman WHERE id = '$id'";
$result_check = mysqli_query($koneksi, $query_check);

if (!$result_check || mysqli_num_rows($result_check) == 0) {
    $_SESSION['message'] = "Peminjaman tidak ditemukan!";
    $_SESSION['message_type'] = "error";
    header("Location: index.php");
    exit();
}

$peminjaman = mysqli_fetch_assoc($result_check);

// Transaction
mysqli_begin_transaction($koneksi);

try {
    // Kembalikan stok buku
    $query_buku = "UPDATE buku SET stok = stok + 1 WHERE id = '{$peminjaman['buku_id']}'";
    mysqli_query($koneksi, $query_buku);

    // Update status buku menjadi tersedia
    $query_status = "UPDATE buku SET status = 'tersedia' WHERE id = '{$peminjaman['buku_id']}'";
    mysqli_query($koneksi, $query_status);

    // Hapus peminjaman
    $query_delete = "DELETE FROM peminjaman WHERE id = '$id'";
    mysqli_query($koneksi, $query_delete);

    // Commit
    mysqli_commit($koneksi);

    $_SESSION['message'] = "Peminjaman berhasil dihapus!";
    $_SESSION['message_type'] = "success";

} catch (Exception $e) {
    mysqli_rollback($koneksi);

    $_SESSION['message'] = "Gagal menghapus peminjaman!";
    $_SESSION['message_type'] = "error";
}

header("Location: index.php");
exit();
?>
