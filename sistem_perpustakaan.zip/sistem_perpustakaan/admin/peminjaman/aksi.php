<?php
require_once '../../koneksi.php';

// Cek login
if (!is_logged_in()) {
    redirect('../../login.php');
}

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = clean_input($_POST['action']);
    $id = clean_input($_POST['id']);
    
    if ($action == 'update_status') {
        $status = clean_input($_POST['status']);
        
        $query = "UPDATE peminjaman SET status = '$status' WHERE id = '$id'";
        
        if (mysqli_query($koneksi, $query)) {
            echo json_encode(['success' => true, 'message' => 'Status berhasil diubah']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal mengubah status']);
        }
    }
    
    if ($action == 'kembalikan_buku') {
        $tanggal_kembali = date('Y-m-d');
        
        // Ambil data peminjaman
        $query_pinjam = "SELECT *, DATEDIFF('$tanggal_kembali', batas_kembali) as terlambat_hari 
                        FROM peminjaman WHERE id = '$id'";
        $result_pinjam = mysqli_query($koneksi, $query_pinjam);
        $pinjam = mysqli_fetch_assoc($result_pinjam);
        
        // Hitung denda
        $denda = 0;
        $terlambat_hari = max(0, $pinjam['terlambat_hari']);
        if ($terlambat_hari > 0) {
            $denda = $terlambat_hari * 2000; // Rp 2.000 per hari
        }
        
        // Mulai transaction
        mysqli_begin_transaction($koneksi);
        
        try {
            // Update peminjaman
            $query_update = "UPDATE peminjaman SET 
                            tanggal_kembali = '$tanggal_kembali',
                            denda = '$denda',
                            status = 'selesai'
                            WHERE id = '$id'";
            mysqli_query($koneksi, $query_update);
            
            // Update stok buku
            $query_buku = "UPDATE buku SET stok = stok + 1, status = 'tersedia' WHERE id = '{$pinjam['buku_id']}'";
            mysqli_query($koneksi, $query_buku);
            
            // Jika ada denda, tambah ke tabel denda
            if ($denda > 0) {
                $query_denda = "INSERT INTO denda (anggota_id, peminjaman_id, jumlah, status) 
                               VALUES ('{$pinjam['anggota_id']}', '$id', '$denda', 'belum_lunas')";
                mysqli_query($koneksi, $query_denda);
            }
            
            // Commit transaction
            mysqli_commit($koneksi);
            
            echo json_encode(['success' => true, 'message' => 'Buku berhasil dikembalikan!']);
            
        } catch (Exception $e) {
            // Rollback transaction
            mysqli_rollback($koneksi);
            echo json_encode(['success' => false, 'message' => 'Gagal: ' . $e->getMessage()]);
        }
    }
}

// AJAX get peminjaman
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_peminjaman') {
    $id = clean_input($_GET['id']);
    
    $query = "SELECT p.*, a.nama as nama_anggota, a.kode_anggota, b.judul as judul_buku, b.isbn 
              FROM peminjaman p
              JOIN anggota a ON p.anggota_id = a.id
              JOIN buku b ON p.buku_id = b.id
              WHERE p.id = '$id'";
    $result = mysqli_query($koneksi, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $peminjaman = mysqli_fetch_assoc($result);
        echo json_encode(['success' => true, 'data' => $peminjaman]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Peminjaman tidak ditemukan']);
    }
    exit();
}
?>