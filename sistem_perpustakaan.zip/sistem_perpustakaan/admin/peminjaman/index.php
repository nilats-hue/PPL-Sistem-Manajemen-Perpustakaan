<?php
$page_title = "Peminjaman";
$page_subtitle = "Kelola transaksi peminjaman buku";
require_once '../header.php';
require_once '../../koneksi.php';

// Ambil data peminjaman - PERBAIKI NAMA KOLOM
$query = "SELECT p.*, a.nama as nama_anggota, a.kode_anggota, b.judul as judul_buku, b.isbn 
          FROM peminjaman p
          JOIN anggota a ON p.anggota_id = a.id
          JOIN buku b ON p.buku_id = b.id
          ORDER BY p.created_at DESC";
$result = mysqli_query($koneksi, $query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title">
            <i class="fas fa-exchange-alt me-2"></i>Data Peminjaman Buku
        </h5>
        <div>
            <a href="tambah.php" class="btn btn-maroon">
                <i class="fas fa-plus-circle me-1"></i>Peminjaman Baru
            </a>
            <a href="../cetakPdf.php?type=peminjaman" class="btn btn-outline-maroon ms-2">
                <i class="fas fa-file-pdf me-1"></i>Laporan
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table datatable">
                <thead>
                    <tr>
                        <th width="50">No</th>
                        <th>Kode</th>
                        <th>Anggota</th>
                        <th>Buku</th>
                        <th>Tanggal Pinjam</th>
                        <th>Batas Kembali</th>
                        <th>Tanggal Kembali</th>
                        <th>Denda</th>
                        <th>Status</th>
                        <th width="180">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php $no = 1; ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): 
                            // Hitung denda jika terlambat
                            $denda = $row['denda'];
                            $status = $row['status'];
                            
                            // PERBAIKAN: Hitung denda otomatis jika status terlambat
                            if ($status == 'terlambat' && !$row['tanggal_kembali']) {
                                $hari_terlambat = max(0, floor((time() - strtotime($row['batas_kembali'])) / 86400));
                                $denda = $hari_terlambat * 2000; // Rp 2.000 per hari
                            }
                            
                            // PERBAIKAN: Update status jika sudah lewat batas kembali
                            if ($status == 'berjalan' && !$row['tanggal_kembali']) {
                                $hari_sekarang = time();
                                $batas_kembali = strtotime($row['batas_kembali']);
                                if ($hari_sekarang > $batas_kembali) {
                                    $status = 'terlambat';
                                    // Update status di database
                                    $update_query = "UPDATE peminjaman SET status = 'terlambat' WHERE id = {$row['id']}";
                                    mysqli_query($koneksi, $update_query);
                                }
                            }
                        ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td>
                                    <strong class="text-maroon"><?php echo htmlspecialchars($row['kode_peminjaman'] ?? 'Belum ada kode'); ?></strong>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['nama_anggota']); ?></strong><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($row['kode_anggota']); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars(substr($row['judul_buku'], 0, 30)); ?>...</strong><br>
                                    <small class="text-muted">ISBN: <?php echo htmlspecialchars($row['isbn']); ?></small>
                                </td>
                                <td>
                                    <?php 
                                    // PERBAIKAN PENTING: Gunakan tanggal_pinjaman bukan tanggal_pinjam
                                    if (!empty($row['tanggal_pinjaman'])) {
                                        echo tgl_indo($row['tanggal_pinjaman']);
                                    } elseif (!empty($row['tanggal_pinjam'])) {
                                        // Fallback jika ada kolom tanggal_pinjam
                                        echo tgl_indo($row['tanggal_pinjam']);
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php echo tgl_indo($row['batas_kembali']); ?>
                                    <?php if ($status == 'terlambat'): ?>
                                        <br><small class="text-danger">Terlambat</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo $row['tanggal_kembali'] ? tgl_indo($row['tanggal_kembali']) : '-'; ?>
                                </td>
                                <td>
                                    <?php if ($denda > 0): ?>
                                        <span class="badge bg-danger">Rp <?php echo number_format($denda, 0, ',', '.'); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    $status_class = '';
                                    switch($status) {
                                        case 'diajukan': $status_class = 'bg-warning'; break;
                                        case 'disetujui': $status_class = 'bg-info'; break;
                                        case 'berjalan': $status_class = 'bg-primary'; break;
                                        case 'terlambat': $status_class = 'bg-danger'; break;
                                        case 'selesai': 
                                        case 'dikembalikan': 
                                            $status_class = 'bg-success'; break;
                                        default: $status_class = 'bg-secondary';
                                    }
                                    ?>
                                    <span class="badge <?php echo $status_class; ?>">
                                        <?php echo ucfirst($status); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="edit.php?id=<?php echo $row['id']; ?>" 
                                           class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="hapus.php?id=<?php echo $row['id']; ?>" 
                                           class="btn btn-danger btn-sm" 
                                           onclick="return confirm('Yakin hapus peminjaman ini?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <a href="invoice.php?id=<?php echo $row['id']; ?>" 
                                           class="btn btn-info btn-sm" target="_blank">
                                            <i class="fas fa-receipt"></i>
                                        </a>
                                        <?php if ($status == 'berjalan' || $status == 'terlambat'): ?>
                                            <a href="../pengembalian/tambah.php?peminjaman_id=<?php echo $row['id']; ?>" 
                                               class="btn btn-success btn-sm">
                                                <i class="fas fa-undo"></i> Kembalikan
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center py-4">
                                <i class="fas fa-book-open fa-3x text-muted mb-3"></i><br>
                                <span class="text-muted">Belum ada data peminjaman</span><br>
                                <a href="tambah.php" class="btn btn-maroon btn-sm mt-2">
                                    <i class="fas fa-plus-circle me-1"></i>Tambah Peminjaman
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// JavaScript untuk konfirmasi hapus
document.querySelectorAll('.confirm-delete').forEach(link => {
    link.addEventListener('click', function(e) {
        if (!confirm('Yakin ingin menghapus peminjaman ini?')) {
            e.preventDefault();
        }
    });
});
</script>

<?php require_once '../footer.php'; ?>