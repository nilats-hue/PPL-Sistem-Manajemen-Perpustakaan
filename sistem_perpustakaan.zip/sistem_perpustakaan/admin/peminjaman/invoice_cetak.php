<?php
require_once '../../koneksi.php';

// Cek login
if (!is_logged_in()) {
    redirect('../../login.php');
}

// Ambil ID dari URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID peminjaman tidak valid!");
}

$id = clean_input($_GET['id']);

// Ambil data peminjaman
$query = "SELECT p.*, a.nama as nama_anggota, a.kode_anggota, a.alamat, a.telepon, 
                 b.judul as judul_buku, b.isbn, b.penulis, b.penerbit
          FROM peminjaman p
          JOIN anggota a ON p.anggota_id = a.id
          JOIN buku b ON p.buku_id = b.id
          WHERE p.id = '$id'";
$result = mysqli_query($koneksi, $query);

if (mysqli_num_rows($result) == 0) {
    die("Peminjaman tidak ditemukan!");
}

$peminjaman = mysqli_fetch_assoc($result);

// Hitung denda
if (!$peminjaman['tanggal_kembali'] && $peminjaman['status'] == 'terlambat') {
    $hari_terlambat = max(0, (strtotime(date('Y-m-d')) - strtotime($peminjaman['batas_kembali'])) / 86400);
    $denda = $hari_terlambat * 2000;
} else {
    $denda = $peminjaman['denda'];
}

// Include Dompdf library
require_once '../../assets/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Create PDF
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);

$html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Invoice Peminjaman - ' . $peminjaman['kode_peminjaman'] . '</title>
    <style>
        @page { margin: 50px; }
        body { font-family: Arial, sans-serif; color: #333; line-height: 1.6; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #800000; padding-bottom: 20px; }
        .logo { font-size: 24px; font-weight: bold; color: #800000; margin-bottom: 10px; }
        .title { font-size: 20px; font-weight: bold; color: #333; margin-bottom: 5px; }
        .subtitle { font-size: 14px; color: #666; }
        .info-container { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .info-box { width: 48%; }
        .info-title { color: #800000; font-size: 16px; font-weight: bold; margin-bottom: 10px; border-bottom: 1px solid #ddd; padding-bottom: 5px; }
        .info-row { margin-bottom: 5px; }
        .label { font-weight: bold; display: inline-block; width: 120px; }
        .value { display: inline-block; }
        .table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        .table th { background: #800000; color: white; padding: 10px; text-align: left; font-weight: bold; }
        .table td { padding: 10px; border: 1px solid #ddd; }
        .summary { float: right; width: 300px; }
        .summary-row { display: flex; justify-content: space-between; margin-bottom: 10px; padding: 5px 0; }
        .summary-label { font-weight: bold; }
        .summary-value { text-align: right; }
        .total { border-top: 2px solid #800000; padding-top: 10px; font-size: 16px; font-weight: bold; }
        .footer { margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; text-align: center; }
        .status { display: inline-block; padding: 5px 15px; border-radius: 15px; font-weight: bold; }
        .status-berjalan { background: #d4edda; color: #155724; }
        .status-selesai { background: #cce5ff; color: #004085; }
        .status-terlambat { background: #f8d7da; color: #721c24; }
        .notes { margin-top: 30px; font-size: 12px; color: #666; }
        .notes-title { font-weight: bold; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">UNIVERSITAS TANGERANG RAYA</div>
        <div class="title">PERPUSTAKAAN DIGITAL</div>
        <div class="subtitle">Bukti Peminjaman Buku</div>
    </div>

    <div class="info-container">
        <div class="info-box">
            <div class="info-title">Informasi Anggota</div>
            <div class="info-row"><span class="label">Nama:</span> <span class="value">' . $peminjaman['nama_anggota'] . '</span></div>
            <div class="info-row"><span class="label">Kode Anggota:</span> <span class="value">' . $peminjaman['kode_anggota'] . '</span></div>
            <div class="info-row"><span class="label">Alamat:</span> <span class="value">' . $peminjaman['alamat'] . '</span></div>
            <div class="info-row"><span class="label">Telepon:</span> <span class="value">' . $peminjaman['telepon'] . '</span></div>
        </div>
        
        <div class="info-box">
            <div class="info-title">Informasi Transaksi</div>
            <div class="info-row"><span class="label">Kode Peminjaman:</span> <span class="value">' . $peminjaman['kode_peminjaman'] . '</span></div>
            <div class="info-row"><span class="label">Tanggal Pinjam:</span> <span class="value">' . date('d/m/Y', strtotime($peminjaman['tanggal_pinjam'])) . '</span></div>
            <div class="info-row"><span class="label">Batas Kembali:</span> <span class="value">' . date('d/m/Y', strtotime($peminjaman['batas_kembali'])) . '</span></div>
            <div class="info-row"><span class="label">Status:</span> <span class="value"><span class="status status-' . $peminjaman['status'] . '">' . ucfirst($peminjaman['status']) . '</span></span></div>
            <div class="info-row"><span class="label">Invoice No:</span> <span class="value">INV' . str_pad($id, 6, '0', STR_PAD_LEFT) . '</span></div>
        </div>
    </div>

    <div class="info-title">Detail Buku</div>
    <table class="table">
        <thead>
            <tr>
                <th>Judul Buku</th>
                <th>Penulis</th>
                <th>ISBN</th>
                <th>Penerbit</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>' . $peminjaman['judul_buku'] . '</td>
                <td>' . $peminjaman['penulis'] . '</td>
                <td>' . ($peminjaman['isbn'] ?: '-') . '</td>
                <td>' . ($peminjaman['penerbit'] ?: '-') . '</td>
            </tr>
        </tbody>
    </table>

    <div class="summary">
        <div class="info-title">Ringkasan</div>
        <div class="summary-row">
            <span class="summary-label">Tanggal Pinjam:</span>
            <span class="summary-value">' . date('d/m/Y', strtotime($peminjaman['tanggal_pinjam'])) . '</span>
        </div>
        <div class="summary-row">
            <span class="summary-label">Batas Kembali:</span>
            <span class="summary-value">' . date('d/m/Y', strtotime($peminjaman['batas_kembali'])) . '</span>
        </div>';
        
        if ($peminjaman['tanggal_kembali']) {
            $html .= '<div class="summary-row">
                <span class="summary-label">Tanggal Kembali:</span>
                <span class="summary-value">' . date('d/m/Y', strtotime($peminjaman['tanggal_kembali'])) . '</span>
            </div>';
        }
        
        if ($denda > 0) {
            $html .= '<div class="summary-row">
                <span class="summary-label">Denda:</span>
                <span class="summary-value">Rp ' . number_format($denda, 0, ',', '.') . '</span>
            </div>';
        }
        
        $html .= '<div class="summary-row total">
            <span class="summary-label">Total:</span>
            <span class="summary-value">' . ($denda > 0 ? 'Rp ' . number_format($denda, 0, ',', '.') : 'Tidak ada denda') . '</span>
        </div>
    </div>

    <div class="notes">
        <div class="notes-title">Catatan Penting:</div>
        <p>1. Buku harus dikembalikan sebelum tanggal ' . date('d/m/Y', strtotime($peminjaman['batas_kembali'])) . '</p>
        <p>2. Denda keterlambatan Rp 2.000 per hari</p>
        <p>3. Bukti ini harus disimpan untuk pengembalian buku</p>
        <p>4. Hubungi perpustakaan UTR untuk informasi lebih lanjut</p>
    </div>

    <div class="footer">
        <p>Dicetak pada: ' . date('d/m/Y H:i:s') . '</p>
        <p>Perpustakaan Universitas Tangerang Raya &copy; ' . date('Y') . '</p>
    </div>
</body>
</html>';

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Output PDF
$dompdf->stream('invoice-peminjaman-' . $peminjaman['kode_peminjaman'] . '.pdf', array('Attachment' => 1));
?>