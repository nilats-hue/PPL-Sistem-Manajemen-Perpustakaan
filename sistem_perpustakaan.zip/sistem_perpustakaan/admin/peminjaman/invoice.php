<?php
$page_title = "Invoice Peminjaman";
require_once '../header.php';
require_once '../../koneksi.php';

// Ambil ID dari URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message("ID peminjaman tidak valid!", 'error');
    redirect('index.php');
}

$id = clean_input($_GET['id']);

// Ambil data peminjaman
$query = "SELECT p.*, a.nama as nama_anggota, a.kode_anggota, a.alamat, a.telepon, 
                 b.judul as judul_buku, b.isbn, b.penulis, b.penerbit
          FROM peminjaman p
          JOIN anggota a ON p.anggota_id = a.id
          JOIN buku b ON p.buku_id = b.id
          WHERE p.id = '$id'";
$result = mysqli_query($koneksi, $query);

if (mysqli_num_rows($result) == 0) {
    set_message("Peminjaman tidak ditemukan!", 'error');
    redirect('index.php');
}

$peminjaman = mysqli_fetch_assoc($result);

// Hitung denda jika belum ada
if (!$peminjaman['tanggal_kembali'] && $peminjaman['status'] == 'terlambat') {
    $hari_terlambat = max(0, (strtotime(date('Y-m-d')) - strtotime($peminjaman['batas_kembali'])) / 86400);
    $denda = $hari_terlambat * 2000;
} else {
    $denda = $peminjaman['denda'];
}
?>

<style>
    @media print {
        .no-print {
            display: none !important;
        }
        .invoice-container {
            box-shadow: none !important;
            border: none !important;
        }
        body {
            background: white !important;
        }
    }
    
    .invoice-container {
        max-width: 800px;
        margin: 0 auto;
        background: white;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        overflow: hidden;
    }
    
    .invoice-header {
        background: linear-gradient(135deg, var(--maroon) 0%, var(--maroon-dark) 100%);
        color: white;
        padding: 30px;
        text-align: center;
    }
    
    .invoice-logo {
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 10px;
    }
    
    .invoice-title {
        font-size: 1.5rem;
        margin-bottom: 5px;
    }
    
    .invoice-subtitle {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    
    .invoice-body {
        padding: 40px;
    }
    
    .invoice-info {
        display: flex;
        justify-content: space-between;
        margin-bottom: 40px;
    }
    
    .info-section h5 {
        color: var(--maroon);
        margin-bottom: 15px;
        border-bottom: 2px solid #eee;
        padding-bottom: 5px;
    }
    
    .info-section p {
        margin: 5px 0;
        color: #555;
    }
    
    .invoice-details {
        margin-bottom: 30px;
    }
    
    .invoice-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
    }
    
    .invoice-table th {
        background: #f8f9fa;
        padding: 15px;
        text-align: left;
        color: var(--maroon);
        border-bottom: 2px solid #eee;
    }
    
    .invoice-table td {
        padding: 15px;
        border-bottom: 1px solid #eee;
    }
    
    .invoice-table tr:last-child td {
        border-bottom: none;
    }
    
    .invoice-total {
        text-align: right;
        margin-top: 30px;
    }
    
    .total-row {
        display: flex;
        justify-content: flex-end;
        margin-bottom: 10px;
    }
    
    .total-label {
        width: 150px;
        text-align: right;
        padding-right: 20px;
        color: #666;
    }
    
    .total-value {
        width: 150px;
        text-align: right;
        font-weight: 600;
    }
    
    .total-grand {
        border-top: 2px solid #eee;
        padding-top: 10px;
        margin-top: 10px;
        font-size: 1.2rem;
        color: var(--maroon);
    }
    
    .invoice-footer {
        background: #f8f9fa;
        padding: 30px;
        text-align: center;
        border-top: 1px solid #eee;
    }
    
    .invoice-footer p {
        color: #666;
        margin: 5px 0;
        font-size: 0.9rem;
    }
    
    .status-badge {
        padding: 8px 20px;
        border-radius: 20px;
        font-weight: 600;
        display: inline-block;
    }
    
    .status-berjalan {
        background: #d4edda;
        color: #155724;
    }
    
    .status-selesai {
        background: #cce5ff;
        color: #004085;
    }
    
    .status-terlambat {
        background: #f8d7da;
        color: #721c24;
    }
</style>

<div class="no-print mb-4">
    <a href="javascript:window.print()" class="btn btn-maroon">
        <i class="fas fa-print me-2"></i>Cetak Invoice
    </a>
    <a href="index.php" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>Kembali
    </a>
    <a href="invoice_cetak.php?id=<?php echo $id; ?>" class="btn btn-outline-maroon" target="_blank">
        <i class="fas fa-file-pdf me-2"></i>Download PDF
    </a>
</div>

<div class="invoice-container">
    <div class="invoice-header">
        <div class="invoice-logo">UTR</div>
        <div class="invoice-title">UNIVERSITAS TANGERANG RAYA</div>
        <div class="invoice-subtitle">Perpustakaan Digital - Bukti Peminjaman Buku</div>
    </div>
    
    <div class="invoice-body">
        <div class="invoice-info">
            <div class="info-section">
                <h5>Informasi Anggota</h5>
                <p><strong>Nama:</strong> <?php echo $peminjaman['nama_anggota']; ?></p>
                <p><strong>Kode:</strong> <?php echo $peminjaman['kode_anggota']; ?></p>
                <p><strong>Alamat:</strong> <?php echo $peminjaman['alamat']; ?></p>
                <p><strong>Telepon:</strong> <?php echo $peminjaman['telepon']; ?></p>
            </div>
            
            <div class="info-section">
                <h5>Informasi Transaksi</h5>
                <p><strong>Kode:</strong> <?php echo $peminjaman['kode_peminjaman']; ?></p>
                <p><strong>Tanggal:</strong> <?php echo tgl_indo($peminjaman['tanggal_pinjam']); ?></p>
                <p><strong>Status:</strong> 
                    <span class="status-badge status-<?php echo $peminjaman['status']; ?>">
                        <?php echo ucfirst($peminjaman['status']); ?>
                    </span>
                </p>
                <p><strong>Nomor Invoice:</strong> INV<?php echo str_pad($id, 6, '0', STR_PAD_LEFT); ?></p>
            </div>
        </div>
        
        <div class="invoice-details">
            <h5 style="color: var(--maroon); margin-bottom: 20px;">Detail Buku</h5>
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Judul Buku</th>
                        <th>Penulis</th>
                        <th>ISBN</th>
                        <th>Penerbit</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $peminjaman['judul_buku']; ?></td>
                        <td><?php echo $peminjaman['penulis']; ?></td>
                        <td><?php echo $peminjaman['isbn'] ?: '-'; ?></td>
                        <td><?php echo $peminjaman['penerbit'] ?: '-'; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="invoice-total">
            <div class="total-row">
                <div class="total-label">Tanggal Pinjam:</div>
                <div class="total-value"><?php echo tgl_indo($peminjaman['tanggal_pinjam']); ?></div>
            </div>
            <div class="total-row">
                <div class="total-label">Batas Kembali:</div>
                <div class="total-value"><?php echo tgl_indo($peminjaman['batas_kembali']); ?></div>
            </div>
            <?php if ($peminjaman['tanggal_kembali']): ?>
            <div class="total-row">
                <div class="total-label">Tanggal Kembali:</div>
                <div class="total-value"><?php echo tgl_indo($peminjaman['tanggal_kembali']); ?></div>
            </div>
            <?php endif; ?>
            
            <?php if ($denda > 0): ?>
            <div class="total-row">
                <div class="total-label">Denda Keterlambatan:</div>
                <div class="total-value"><?php echo format_rupiah($denda); ?></div>
            </div>
            <?php endif; ?>
            
            <?php if ($peminjaman['keterangan']): ?>
            <div class="total-row">
                <div class="total-label">Keterangan:</div>
                <div class="total-value"><?php echo $peminjaman['keterangan']; ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="invoice-footer">
        <p><strong>Catatan:</strong></p>
        <p>1. Buku harus dikembalikan sebelum tanggal <?php echo tgl_indo($peminjaman['batas_kembali']); ?></p>
        <p>2. Denda keterlambatan Rp 2.000 per hari</p>
        <p>3. Simpan bukti ini untuk pengembalian buku</p>
        <p>4. Untuk informasi lebih lanjut, hubungi perpustakaan UTR</p>
    </div>
</div>

<?php require_once '../footer.php'; ?>