<?php
require_once '../../koneksi.php';

// Cek login
if (!is_logged_in()) {
    redirect('../../login.php');
}

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = clean_input($_POST['action']);
    $id = clean_input($_POST['id']);
    
    if ($action == 'update_status') {
        $status = clean_input($_POST['status']);
        
        $query = "UPDATE anggota SET status = '$status' WHERE id = '$id'";
        
        if (mysqli_query($koneksi, $query)) {
            echo json_encode(['success' => true, 'message' => 'Status berhasil diubah']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal mengubah status']);
        }
    }
}
?>