<?php
ob_start(); // HARUS PALING ATAS

$page_title    = "Edit Anggota";
$page_subtitle = "Edit data anggota";

require_once '../header.php';

// ===============================
// VALIDASI ID
// ===============================
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message("ID anggota tidak valid!", 'error');
    redirect('index.php');
}

$id = clean_input($_GET['id']);

// ===============================
// AMBIL DATA ANGGOTA
// ===============================
$query  = "SELECT * FROM anggota WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    set_message("Anggota tidak ditemukan!", 'error');
    redirect('index.php');
}

$anggota = mysqli_fetch_assoc($result);

// ===============================
// PROSES UPDATE
// ===============================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama          = clean_input($_POST['nama'] ?? '');
    $jenis_kelamin = clean_input($_POST['jenis_kelamin'] ?? '');
    $alamat        = clean_input($_POST['alamat'] ?? '');
    $telepon       = clean_input($_POST['telepon'] ?? '');
    $email         = clean_input($_POST['email'] ?? '');
    $status        = clean_input($_POST['status'] ?? '');

    if ($nama === '') {
        set_message("Nama lengkap wajib diisi!", 'warning');
    } else {

        $update = "UPDATE anggota SET 
                    nama = '$nama',
                    jenis_kelamin = '$jenis_kelamin',
                    alamat = '$alamat',
                    telepon = '$telepon',
                    email = '$email',
                    status = '$status'
                   WHERE id = '$id'";

        if (mysqli_query($koneksi, $update)) {
            set_message("Data anggota berhasil diperbarui!", 'success');
            redirect('index.php');
        } else {
            set_message("Gagal memperbarui data: " . mysqli_error($koneksi), 'error');
        }
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-edit me-2"></i> Form Edit Anggota
                </h5>
            </div>

            <div class="card-body">
                <form method="POST">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kode Anggota</label>
                            <input type="text" class="form-control"
                                   value="<?php echo htmlspecialchars($anggota['kode_anggota']); ?>" readonly>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="aktif"     <?php echo $anggota['status'] === 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                <option value="diblokir"  <?php echo $anggota['status'] === 'diblokir' ? 'selected' : ''; ?>>Diblokir</option>
                                <option value="nonaktif" <?php echo $anggota['status'] === 'nonaktif' ? 'selected' : ''; ?>>Nonaktif</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control" required
                               value="<?php echo htmlspecialchars($anggota['nama']); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-select">
                                <option value="L" <?php echo $anggota['jenis_kelamin'] === 'L' ? 'selected' : ''; ?>>Laki-laki</option>
                                <option value="P" <?php echo $anggota['jenis_kelamin'] === 'P' ? 'selected' : ''; ?>>Perempuan</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Telepon</label>
                            <input type="tel" name="telepon" class="form-control"
                                   value="<?php echo htmlspecialchars($anggota['telepon']); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control"
                               value="<?php echo htmlspecialchars($anggota['email']); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Alamat</label>
                        <textarea name="alamat" class="form-control" rows="3"><?php
                            echo htmlspecialchars($anggota['alamat']);
                        ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Daftar</label>
                            <input type="text" class="form-control" readonly
                                   value="<?php echo tgl_indo($anggota['tanggal_daftar']); ?>">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tanggal Expired</label>
                            <input type="text" class="form-control" readonly
                                   value="<?php echo tgl_indo($anggota['tanggal_expired']); ?>">
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-maroon me-2">
                            <i class="fas fa-save me-1"></i> Simpan Perubahan
                        </button>

                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Batal
                        </a>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php
require_once '../footer.php';
ob_end_flush();
?>
