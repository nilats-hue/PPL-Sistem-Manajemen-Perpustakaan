<?php
// admin/anggota/hapus.php
session_start();

// Path ke koneksi.php
$koneksi_path = __DIR__ . '/../../koneksi.php';

if (!file_exists($koneksi_path)) {
    die("ERROR: File koneksi.php tidak ditemukan!");
}

require_once $koneksi_path;

// ===============================
// DEFINE FUNCTIONS JIKA BELUM ADA
// ===============================
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
}

if (!function_exists('redirect')) {
    function redirect($url) {
        header("Location: $url");
        exit();
    }
}

if (!function_exists('set_message')) {
    function set_message($message, $type = 'success') {
        $_SESSION['message'] = $message;
        $_SESSION['message_type'] = $type;
    }
}

if (!function_exists('clean_input')) {
    function clean_input($data) {
        global $koneksi;
        if (!isset($data) || $data === null) {
            return '';
        }
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return mysqli_real_escape_string($koneksi, $data);
    }
}

// ===============================
// CEK LOGIN
// ===============================
if (!is_logged_in()) {
    $_SESSION['message'] = "Silakan login terlebih dahulu!";
    $_SESSION['message_type'] = 'error';
    redirect('../../login.php');
}

// ===============================
// CEK PARAMETER ID
// ===============================
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message("ID anggota tidak valid!", 'error');
    redirect('index.php');
}

$id = intval($_GET['id']); // Gunakan intval untuk keamanan

// ===============================
// CEK APAKAH ANGGOTA ADA
// ===============================
$query_check = "SELECT * FROM anggota WHERE id = $id";
$result_check = mysqli_query($koneksi, $query_check);

if (!$result_check || mysqli_num_rows($result_check) == 0) {
    set_message("Anggota tidak ditemukan!", 'error');
    redirect('index.php');
}

// ===============================
// OPTIONAL: CEK APAKAH MASIH ADA PEMINJAMAN AKTIF
// ===============================
$total_pinjam = 0;
$query_pinjam = "SELECT COUNT(*) as total 
                 FROM peminjaman 
                 WHERE anggota_id = $id 
                   AND status IN ('dipinjam', 'terlambat')";
$result_pinjam = mysqli_query($koneksi, $query_pinjam);

if ($result_pinjam) {
    $row_pinjam   = mysqli_fetch_assoc($result_pinjam);
    $total_pinjam = (int) $row_pinjam['total'];
}

if ($total_pinjam > 0) {
    set_message("Anggota tidak dapat dihapus karena masih memiliki peminjaman aktif!", 'error');
    redirect('index.php');
}

// ===============================
// HAPUS DATA
// ===============================
$query = "DELETE FROM anggota WHERE id = $id";

if (mysqli_query($koneksi, $query)) {
    set_message("Anggota berhasil dihapus!", 'success');
} else {
    set_message("Gagal menghapus anggota: " . mysqli_error($koneksi), 'error');
}

// ===============================
// REDIRECT BALIK KE INDEX ANGGOTA
// ===============================
redirect('index.php');
