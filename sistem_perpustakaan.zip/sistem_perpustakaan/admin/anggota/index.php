<?php
// Mulai session
session_start();

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$page_title = "Data Anggota";
$page_subtitle = "Kelola data anggota perpustakaan";

// Sertakan koneksi
require_once '../../koneksi.php';

// Fungsi helper jika belum ada
if (!function_exists('tgl_indo')) {
    function tgl_indo($tanggal) {
        if (empty($tanggal) || $tanggal == '0000-00-00') {
            return '-';
        }
        $bulan = array(
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        );
        $pecah = explode('-', $tanggal);
        return $pecah[2] . ' ' . $bulan[(int)$pecah[1]] . ' ' . $pecah[0];
    }
}

// Sertakan header
require_once '../header.php';

// Ambil data anggota
$query = "SELECT * FROM anggota ORDER BY created_at DESC";
$result = mysqli_query($koneksi, $query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title">
            <i class="fas fa-users me-2"></i>Daftar Anggota Perpustakaan
        </h5>

        <!-- FIX: RELATIVE PATH -->
        <a href="./tambah.php" class="btn btn-maroon">
            <i class="fas fa-plus-circle me-1"></i>Tambah Anggota
        </a>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table datatable">
                <thead>
                    <tr>
                        <th width="50">No</th>
                        <th>Kode Anggota</th>
                        <th>Nama Lengkap</th>
                        <th>Jenis Kelamin</th>
                        <th>Telepon</th>
                        <th>Email</th>
                        <th>Tanggal Daftar</th>
                        <th>Status</th>
                        <th width="150">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php $no = 1; ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td>
                                    <strong class="text-maroon"><?php echo $row['kode_anggota']; ?></strong>
                                </td>
                                <td>
                                    <strong><?php echo $row['nama']; ?></strong><br>
                                    <small class="text-muted"><?php echo $row['alamat'] ? substr($row['alamat'], 0, 30) . '...' : '-'; ?></small>
                                </td>
                                <td><?php echo $row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                                <td><?php echo $row['telepon'] ?: '-'; ?></td>
                                <td><?php echo $row['email'] ?: '-'; ?></td>
                                <td><?php echo tgl_indo($row['tanggal_daftar']); ?></td>
                                <td>
                                    <?php 
                                    $status_class = '';
                                    switch($row['status']) {
                                        case 'aktif': $status_class = 'badge bg-success'; break;
                                        case 'diblokir': $status_class = 'badge bg-danger'; break;
                                        case 'nonaktif': $status_class = 'badge bg-warning'; break;
                                        default: $status_class = 'badge bg-secondary';
                                    }
                                    ?>
                                    <span class="<?php echo $status_class; ?>">
                                        <?php echo ucfirst($row['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">

                                        <!-- FIX: RELATIVE PATH -->
                                        <a href="./edit.php?id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <!-- FIX: RELATIVE PATH -->
                                        <a href="./hapus.php?id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Yakin hapus anggota ini?')">
                                            <i class="fas fa-trash"></i>
                                        </a>

                                        <!-- FIX: PATH SALAH (../admin/...) -->
                                        <a href="../cetakPrint.php?type=anggota&id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-info" target="_blank">
                                            <i class="fas fa-print"></i>
                                        </a>

                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center py-4">
                                <div class="text-muted">
                                    <i class="fas fa-users fa-2x mb-3"></i><br>
                                    Belum ada data anggota
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php 
// Sertakan footer
require_once '../footer.php'; 
?>
