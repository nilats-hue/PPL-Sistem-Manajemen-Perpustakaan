<?php
ob_start(); // HARUS PALING ATAS

$page_title    = "Tambah Anggota";
$page_subtitle = "Tambah data anggota baru";

require_once '../header.php';

// ===============================
// GENERATE KODE ANGGOTA
// ===============================
$kode_anggota = generate_kode('ANG');

// ===============================
// PROSES TAMBAH DATA
// ===============================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $kode_anggota  = clean_input($_POST['kode_anggota'] ?? '');
    $nama          = clean_input($_POST['nama'] ?? '');
    $jenis_kelamin = clean_input($_POST['jenis_kelamin'] ?? '');
    $alamat        = clean_input($_POST['alamat'] ?? '');
    $telepon       = clean_input($_POST['telepon'] ?? '');
    $email         = clean_input($_POST['email'] ?? '');

    $tanggal_daftar   = date('Y-m-d');
    $tanggal_expired = date('Y-m-d', strtotime('+1 year'));
    $status           = 'aktif';

    // ===============================
    // VALIDASI
    // ===============================
    $errors = [];

    if ($nama === '') {
        $errors[] = "Nama harus diisi!";
    }

    if (empty($errors)) {

        $stmt = mysqli_prepare($koneksi, "
            INSERT INTO anggota 
            (kode_anggota, nama, jenis_kelamin, alamat, telepon, email, 
             tanggal_daftar, tanggal_expired, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                "sssssssss",
                $kode_anggota,
                $nama,
                $jenis_kelamin,
                $alamat,
                $telepon,
                $email,
                $tanggal_daftar,
                $tanggal_expired,
                $status
            );

            if (mysqli_stmt_execute($stmt)) {
                set_message("Anggota berhasil ditambahkan!", 'success');
                redirect('index.php');
            } else {
                set_message("Gagal menambahkan anggota: " . mysqli_error($koneksi), 'error');
            }

            mysqli_stmt_close($stmt);

        } else {
            set_message("Gagal prepare statement!", 'error');
        }

    } else {
        set_message(implode("<br>", $errors), 'error');
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-user-plus me-2"></i> Form Tambah Anggota
                </h5>
            </div>

            <div class="card-body">
                <form method="POST">

                    <div class="mb-3">
                        <label class="form-label">Kode Anggota</label>
                        <input type="text" name="kode_anggota" class="form-control"
                               value="<?php echo htmlspecialchars($kode_anggota); ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" name="nama" class="form-control" required
                               value="<?php echo htmlspecialchars($_POST['nama'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="form-select">
                            <option value="">-- Pilih --</option>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Telepon</label>
                        <input type="tel" name="telepon" class="form-control"
                               value="<?php echo htmlspecialchars($_POST['telepon'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control"
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Alamat</label>
                        <textarea name="alamat" class="form-control" rows="3"><?php
                            echo htmlspecialchars($_POST['alamat'] ?? '');
                        ?></textarea>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-maroon me-2">
                            <i class="fas fa-save me-1"></i> Simpan
                        </button>

                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-times me-1"></i> Batal
                        </a>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php
require_once '../footer.php';
ob_end_flush();
?>
