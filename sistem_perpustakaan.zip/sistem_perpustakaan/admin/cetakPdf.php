<?php
require_once '../koneksi.php';

// Cek login
if (!is_logged_in()) {
    redirect('../login.php');
}

// Ambil parameter
$jenis = isset($_GET['jenis']) ? clean_input($_GET['jenis']) : 'peminjaman';
$start_date = isset($_GET['start_date']) ? clean_input($_GET['start_date']) : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? clean_input($_GET['end_date']) : date('Y-m-d');
$id = isset($_GET['id']) ? clean_input($_GET['id']) : null;

// Include Dompdf library
require_once '../assets/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Create PDF
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);

$html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laporan Perpustakaan UTR</title>
    <style>
        @page { margin: 50px; }
        body { font-family: Arial, sans-serif; color: #333; line-height: 1.6; font-size: 12px; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #800000; padding-bottom: 20px; }
        .logo { font-size: 24px; font-weight: bold; color: #800000; margin-bottom: 10px; }
        .title { font-size: 20px; font-weight: bold; color: #333; margin-bottom: 5px; }
        .subtitle { font-size: 14px; color: #666; }
        .info { margin-bottom: 20px; }
        .info-row { margin-bottom: 5px; }
        .table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .table th { background: #800000; color: white; padding: 8px; text-align: left; font-weight: bold; }
        .table td { padding: 8px; border: 1px solid #ddd; }
        .footer { margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 10px; color: #666; text-align: center; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .bold { font-weight: bold; }
        .summary { margin-top: 30px; padding: 15px; background: #f8f9fa; border: 1px solid #ddd; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">UNIVERSITAS TANGERANG RAYA</div>
        <div class="title">LAPORAN PERPUSTAKAAN</div>
        <div class="subtitle">Sistem Manajemen Perpustakaan Digital</div>
    </div>
    
    <div class="info">
        <div class="info-row">Periode: ' . date('d/m/Y', strtotime($start_date)) . ' - ' . date('d/m/Y', strtotime($end_date)) . '</div>
        <div class="info-row">Dicetak pada: ' . date('d/m/Y H:i:s') . '</div>
        <div class="info-row">Oleh: ' . $_SESSION['nama'] . ' (' . $_SESSION['role'] . ')</div>
    </div>';

// Ambil data berdasarkan jenis
switch ($jenis) {
    case 'peminjaman':
        $title = 'LAPORAN PEMINJAMAN BUKU';
        
        $query = "SELECT p.*, a.nama as nama_anggota, b.judul as judul_buku 
                 FROM peminjaman p
                 JOIN anggota a ON p.anggota_id = a.id
                 JOIN buku b ON p.buku_id = b.id
                 WHERE p.tanggal_pinjam BETWEEN '$start_date' AND '$end_date'
                 ORDER BY p.tanggal_pinjam DESC";
        $result = mysqli_query($koneksi, $query);
        
        $html .= '<h3 class="text-center" style="color: #800000;">' . $title . '</h3>';
        
        if (mysqli_num_rows($result) > 0) {
            $html .= '<table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Anggota</th>
                        <th>Buku</th>
                        <th>Tanggal Pinjam</th>
                        <th>Batas Kembali</th>
                        <th>Status</th>
                        <th>Denda</th>
                    </tr>
                </thead>
                <tbody>';
            
            $no = 1;
            $total_denda = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                $html .= '<tr>
                    <td>' . $no++ . '</td>
                    <td>' . $row['kode_peminjaman'] . '</td>
                    <td>' . $row['nama_anggota'] . '</td>
                    <td>' . substr($row['judul_buku'], 0, 30) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['tanggal_pinjam'])) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['batas_kembali'])) . '</td>
                    <td>' . ucfirst($row['status']) . '</td>
                    <td class="text-right">' . number_format($row['denda'], 0, ',', '.') . '</td>
                </tr>';
                $total_denda += $row['denda'];
            }
            
            $html .= '</tbody>
                <tfoot>
                    <tr>
                        <td colspan="7" class="text-right bold">Total Denda:</td>
                        <td class="text-right bold">Rp ' . number_format($total_denda, 0, ',', '.') . '</td>
                    </tr>
                    <tr>
                        <td colspan="7" class="text-right bold">Total Data:</td>
                        <td class="text-right bold">' . ($no - 1) . ' transaksi</td>
                    </tr>
                </tfoot>
            </table>';
        } else {
            $html .= '<p class="text-center">Tidak ada data peminjaman pada periode ini.</p>';
        }
        break;
        
    case 'anggota':
        $title = 'LAPORAN DATA ANGGOTA';
        
        $query = "SELECT * FROM anggota 
                 WHERE tanggal_daftar BETWEEN '$start_date' AND '$end_date'
                 ORDER BY nama";
        $result = mysqli_query($koneksi, $query);
        
        $html .= '<h3 class="text-center" style="color: #800000;">' . $title . '</h3>';
        
        if (mysqli_num_rows($result) > 0) {
            $html .= '<table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Jenis Kelamin</th>
                        <th>Telepon</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Tanggal Daftar</th>
                    </tr>
                </thead>
                <tbody>';
            
            $no = 1;
            $aktif = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                $html .= '<tr>
                    <td>' . $no++ . '</td>
                    <td>' . $row['kode_anggota'] . '</td>
                    <td>' . $row['nama'] . '</td>
                    <td>' . ($row['jenis_kelamin'] == 'L' ? 'L' : 'P') . '</td>
                    <td>' . ($row['telepon'] ?: '-') . '</td>
                    <td>' . ($row['email'] ?: '-') . '</td>
                    <td>' . ucfirst($row['status']) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['tanggal_daftar'])) . '</td>
                </tr>';
                
                if ($row['status'] == 'aktif') $aktif++;
            }
            
            $html .= '</tbody>
                <tfoot>
                    <tr>
                        <td colspan="8">
                            <div class="summary">
                                <strong>Ringkasan:</strong><br>
                                Total Anggota: ' . ($no - 1) . '<br>
                                Aktif: ' . $aktif . '<br>
                                Nonaktif: ' . (($no - 1) - $aktif) . '
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>';
        } else {
            $html .= '<p class="text-center">Tidak ada data anggota pada periode ini.</p>';
        }
        break;
        
    case 'buku':
        $title = 'LAPORAN DATA BUKU';
        
        $query = "SELECT * FROM buku ORDER BY judul";
        $result = mysqli_query($koneksi, $query);
        
        $html .= '<h3 class="text-center" style="color: #800000;">' . $title . '</h3>';
        
        if (mysqli_num_rows($result) > 0) {
            $html .= '<table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ISBN</th>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>';
            
            $no = 1;
            $total_stok = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                $html .= '<tr>
                    <td>' . $no++ . '</td>
                    <td>' . ($row['isbn'] ?: '-') . '</td>
                    <td>' . substr($row['judul'], 0, 30) . '</td>
                    <td>' . $row['penulis'] . '</td>
                    <td>' . ($row['penerbit'] ?: '-') . '</td>
                    <td>' . ($row['kategori'] ?: '-') . '</td>
                    <td class="text-right">' . $row['stok'] . '</td>
                    <td>' . ucfirst($row['status']) . '</td>
                </tr>';
                $total_stok += $row['stok'];
            }
            
            $html .= '</tbody>
                <tfoot>
                    <tr>
                        <td colspan="6" class="text-right bold">Total Stok:</td>
                        <td class="text-right bold">' . $total_stok . '</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="6" class="text-right bold">Total Judul:</td>
                        <td class="text-right bold">' . ($no - 1) . ' buku</td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>';
        } else {
            $html .= '<p class="text-center">Tidak ada data buku.</p>';
        }
        break;
}

$html .= '
    <div class="footer">
        <p>Dicetak secara otomatis oleh Sistem Manajemen Perpustakaan UTR</p>
        <p>&copy; ' . date('Y') . ' - Universitas Tangerang Raya</p>
    </div>
</body>
</html>';

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();

// Output PDF
$filename = 'laporan-' . $jenis . '-' . date('Ymd-His') . '.pdf';
$dompdf->stream($filename, array('Attachment' => 1));
?>