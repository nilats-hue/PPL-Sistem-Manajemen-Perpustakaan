<?php
$page_title = "Laporan";
$page_subtitle = "Generate laporan perpustakaan";
require_once 'header.php';
require_once '../koneksi.php';

// Proses filter
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$jenis_laporan = isset($_GET['jenis_laporan']) ? $_GET['jenis_laporan'] : 'peminjaman';

// Ambil data berdasarkan jenis laporan
$data = array();
$title = '';
$headers = array();

switch ($jenis_laporan) {
    case 'peminjaman':
        $title = 'Laporan Peminjaman Buku';
        $headers = ['No', 'Kode', 'Anggota', 'Buku', 'Tanggal Pinjam', 'Batas Kembali', 'Status', 'Denda'];
        
        $query = "SELECT p.*, a.nama as nama_anggota, b.judul as judul_buku 
                 FROM peminjaman p
                 JOIN anggota a ON p.anggota_id = a.id
                 JOIN buku b ON p.buku_id = b.id
                 WHERE p.tanggal_pinjam BETWEEN '$start_date' AND '$end_date'
                 ORDER BY p.tanggal_pinjam DESC";
        $result = mysqli_query($koneksi, $query);
        
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = [
                $no++,
                $row['kode_peminjaman'],
                $row['nama_anggota'],
                substr($row['judul_buku'], 0, 30) . '...',
                tgl_indo($row['tanggal_pinjam']),
                tgl_indo($row['batas_kembali']),
                ucfirst($row['status']),
                format_rupiah($row['denda'])
            ];
        }
        break;
        
    case 'anggota':
        $title = 'Laporan Data Anggota';
        $headers = ['No', 'Kode', 'Nama', 'Jenis Kelamin', 'Telepon', 'Email', 'Status', 'Tanggal Daftar'];
        
        $query = "SELECT * FROM anggota 
                 WHERE tanggal_daftar BETWEEN '$start_date' AND '$end_date'
                 ORDER BY created_at DESC";
        $result = mysqli_query($koneksi, $query);
        
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = [
                $no++,
                $row['kode_anggota'],
                $row['nama'],
                $row['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan',
                $row['telepon'] ?: '-',
                $row['email'] ?: '-',
                ucfirst($row['status']),
                tgl_indo($row['tanggal_daftar'])
            ];
        }
        break;
        
    case 'buku':
        $title = 'Laporan Data Buku';
        $headers = ['No', 'ISBN', 'Judul', 'Penulis', 'Penerbit', 'Kategori', 'Stok', 'Status'];
        
        $query = "SELECT * FROM buku ORDER BY judul";
        $result = mysqli_query($koneksi, $query);
        
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = [
                $no++,
                $row['isbn'] ?: '-',
                substr($row['judul'], 0, 30) . '...',
                $row['penulis'],
                $row['penerbit'] ?: '-',
                $row['kategori'] ?: '-',
                $row['stok'],
                ucfirst($row['status'])
            ];
        }
        break;
        
    case 'denda':
        $title = 'Laporan Denda';
        $headers = ['No', 'Anggota', 'Jumlah Denda', 'Status', 'Tanggal Bayar', 'Keterangan'];
        
        $query = "SELECT d.*, a.nama as nama_anggota 
                 FROM denda d
                 JOIN anggota a ON d.anggota_id = a.id
                 WHERE (d.created_at BETWEEN '$start_date' AND '$end_date')
                 ORDER BY d.created_at DESC";
        $result = mysqli_query($koneksi, $query);
        
        $no = 1;
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = [
                $no++,
                $row['nama_anggota'],
                format_rupiah($row['jumlah']),
                ucfirst($row['status']),
                $row['tanggal_bayar'] ? tgl_indo($row['tanggal_bayar']) : '-',
                $row['keterangan'] ?: '-'
            ];
        }
        break;
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title">
            <i class="fas fa-chart-bar me-2"></i>Generate Laporan
        </h5>
    </div>
    <div class="card-body">
        <!-- Filter Form -->
        <div class="row mb-4">
            <div class="col-md-12">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Jenis Laporan</label>
                        <select name="jenis_laporan" class="form-select">
                            <option value="peminjaman" <?php echo $jenis_laporan == 'peminjaman' ? 'selected' : ''; ?>>Peminjaman</option>
                            <option value="anggota" <?php echo $jenis_laporan == 'anggota' ? 'selected' : ''; ?>>Anggota</option>
                            <option value="buku" <?php echo $jenis_laporan == 'buku' ? 'selected' : ''; ?>>Buku</option>
                            <option value="denda" <?php echo $jenis_laporan == 'denda' ? 'selected' : ''; ?>>Denda</option>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Mulai</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo $start_date; ?>">
                    </div>
                    
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Akhir</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo $end_date; ?>">
                    </div>
                    
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-maroon me-2">
                            <i class="fas fa-filter me-1"></i>Filter
                        </button>
                        <a href="cetakPdf.php?jenis=<?php echo $jenis_laporan; ?>&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
                           class="btn btn-outline-maroon" target="_blank">
                            <i class="fas fa-file-pdf me-1"></i>PDF
                        </a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Laporan -->
        <div class="table-responsive">
            <div class="alert alert-info mb-3">
                <i class="fas fa-info-circle me-2"></i>
                <strong><?php echo $title; ?></strong> - Periode: <?php echo tgl_indo($start_date); ?> s/d <?php echo tgl_indo($end_date); ?>
                <span class="float-end">Total Data: <?php echo count($data); ?></span>
            </div>
            
            <?php if (count($data) > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-maroon">
                            <?php foreach ($headers as $header): ?>
                                <th><?php echo $header; ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data as $row): ?>
                            <tr>
                                <?php foreach ($row as $cell): ?>
                                    <td><?php echo $cell; ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <div class="text-end mt-3">
                    <a href="cetakPdf.php?jenis=<?php echo $jenis_laporan; ?>&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
                       class="btn btn-maroon" target="_blank">
                        <i class="fas fa-print me-2"></i>Cetak Laporan PDF
                    </a>
                    <a href="cetakPrint.php?jenis=<?php echo $jenis_laporan; ?>&start_date=<?php echo $start_date; ?>&end_date=<?php echo $end_date; ?>" 
                       class="btn btn-outline-maroon ms-2" target="_blank">
                        <i class="fas fa-file-excel me-2"></i>Export ke Excel
                    </a>
                </div>
            <?php else: ?>
                <div class="alert alert-warning text-center">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Tidak ada data untuk ditampilkan pada periode yang dipilih.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    .table-maroon {
        background: linear-gradient(135deg, var(--maroon) 0%, var(--maroon-dark) 100%);
        color: white;
    }
</style>

<?php require_once 'footer.php'; ?>