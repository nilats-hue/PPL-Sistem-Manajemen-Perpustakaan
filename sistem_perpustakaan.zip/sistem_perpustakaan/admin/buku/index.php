<?php
$page_title = "Data Buku";
$page_subtitle = "Kelola koleksi buku perpustakaan";
require_once '../header.php';
require_once '../../koneksi.php';

// Debug: Cek kolom yang ada di tabel buku
$debug_query = "SHOW COLUMNS FROM buku";
$debug_result = mysqli_query($koneksi, $debug_query);
$columns = [];
while ($col = mysqli_fetch_assoc($debug_result)) {
    $columns[] = $col['Field'];
}
// echo "<!-- Kolom dalam tabel buku: " . implode(', ', $columns) . " -->";

// Ambil data buku
$query = "SELECT * FROM buku ORDER BY created_at DESC";
$result = mysqli_query($koneksi, $query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title">
            <i class="fas fa-book me-2"></i>Koleksi Buku Perpustakaan
        </h5>
        <div>
            <a href="tambah.php" class="btn btn-maroon">
                <i class="fas fa-plus-circle me-1"></i>Tambah Buku
            </a>
            <a href="../admin/cetakPrint.php?type=buku" class="btn btn-outline-maroon ms-2" target="_blank">
                <i class="fas fa-print me-1"></i>Cetak Laporan
            </a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover datatable">
                <thead class="table-dark">
                    <tr>
                        <th width="50">No</th>
                        <th>ISBN</th>
                        <th>Judul Buku</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Status</th>
                        <th width="150" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php $no = 1; ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td>
                                    <?php if (!empty($row['isbn'])): ?>
                                        <span class="badge bg-dark"><?php echo $row['isbn']; ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong class="text-primary"><?php echo htmlspecialchars($row['judul']); ?></strong>
                                    <?php if (!empty($row['rak'])): ?>
                                        <br><small class="text-muted"><i class="fas fa-archive me-1"></i>Rak: <?php echo $row['rak']; ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['penulis']); ?></td>
                                <td><?php echo !empty($row['penerbit']) ? htmlspecialchars($row['penerbit']) : '-'; ?></td>
                                <td><?php echo !empty($row['tahun_terbit']) ? $row['tahun_terbit'] : '-'; ?></td>
                                <td>
                                    <?php if (!empty($row['kategori'])): ?>
                                        <span class="badge bg-info"><?php echo $row['kategori']; ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php 
                                    $stok = isset($row['stok']) ? (int)$row['stok'] : 0;
                                    $stok_class = ($stok > 0) ? 'bg-success' : 'bg-danger';
                                    ?>
                                    <span class="badge <?php echo $stok_class; ?>">
                                        <i class="fas fa-copy me-1"></i><?php echo $stok; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php 
                                    $status = isset($row['status']) ? $row['status'] : 'tersedia';
                                    $status_class = '';
                                    switch($status) {
                                        case 'tersedia': $status_class = 'bg-success'; break;
                                        case 'dipinjam': $status_class = 'bg-warning'; break;
                                        case 'hilang': $status_class = 'bg-danger'; break;
                                        case 'rusak': $status_class = 'bg-secondary'; break;
                                        default: $status_class = 'bg-info';
                                    }
                                    ?>
                                    <span class="badge <?php echo $status_class; ?>">
                                        <?php echo ucfirst($status); ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group" role="group">
                                        <a href="edit.php?id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-primary" 
                                           title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="hapus.php?id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-danger confirm-delete"
                                           title="Hapus"
                                           onclick="return confirm('Yakin hapus buku <?php echo addslashes($row['judul']); ?>?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <a href="../admin/cetakPrint.php?type=buku&id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-info" 
                                           title="Cetak"
                                           target="_blank">
                                            <i class="fas fa-print"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="fas fa-book fa-3x mb-3"></i>
                                    <h5>Belum ada data buku</h5>
                                    <p>Mulai dengan menambahkan buku pertama Anda</p>
                                    <a href="tambah.php" class="btn btn-maroon mt-2">
                                        <i class="fas fa-plus-circle me-1"></i>Tambah Buku
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer">
        <div class="row">
            <div class="col-md-6">
                <small class="text-muted">
                    <i class="fas fa-info-circle me-1"></i>
                    Total: <?php echo mysqli_num_rows($result); ?> buku
                </small>
            </div>
            <div class="col-md-6 text-end">
                <a href="tambah.php" class="btn btn-sm btn-maroon">
                    <i class="fas fa-plus-circle me-1"></i>Tambah Buku Baru
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once '../footer.php'; ?>