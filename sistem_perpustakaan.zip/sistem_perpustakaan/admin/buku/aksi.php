<?php
require_once '../../koneksi.php';

// Cek login
if (!is_logged_in()) {
    redirect('../../login.php');
}

// Proses aksi
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = clean_input($_POST['action']);
    $id = clean_input($_POST['id']);
    
    if ($action == 'update_stok') {
        $stok = clean_input($_POST['stok']);
        $status = clean_input($_POST['status']);
        
        $query = "UPDATE buku SET stok = '$stok', status = '$status' WHERE id = '$id'";
        
        if (mysqli_query($koneksi, $query)) {
            echo json_encode(['success' => true, 'message' => 'Stok berhasil diupdate']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal mengupdate stok']);
        }
    }
}

// AJAX get buku
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_buku') {
    $id = clean_input($_GET['id']);
    
    $query = "SELECT * FROM buku WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $buku = mysqli_fetch_assoc($result);
        echo json_encode(['success' => true, 'data' => $buku]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Buku tidak ditemukan']);
    }
    exit();
}
?>