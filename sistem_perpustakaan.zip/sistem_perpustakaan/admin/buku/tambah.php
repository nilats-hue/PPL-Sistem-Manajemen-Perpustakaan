<?php
// admin/buku/tambah_simple.php
$page_title = "Tambah Buku";
$page_subtitle = "Tambah buku ke koleksi";

// Start session dan include koneksi
session_start();
require_once '../../koneksi.php';

// Fungsi sederhana untuk sanitasi input
function sanitize($data, $koneksi) {
    if (!isset($data)) return '';
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($koneksi, $data);
}

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

// Proses tambah data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $isbn = sanitize($_POST['isbn'] ?? '', $koneksi);
    $judul = sanitize($_POST['judul'] ?? '', $koneksi);
    $penulis = sanitize($_POST['penulis'] ?? '', $koneksi);
    $penerbit = sanitize($_POST['penerbit'] ?? '', $koneksi);
    $tahun_terbit = sanitize($_POST['tahun_terbit'] ?? '', $koneksi);
    $kategori = sanitize($_POST['kategori'] ?? '', $koneksi);
    $rak = sanitize($_POST['rak'] ?? '', $koneksi);
    $stok = intval($_POST['stok'] ?? 1);
    $status = sanitize($_POST['status'] ?? 'tersedia', $koneksi);
    $deskripsi = sanitize($_POST['deskripsi'] ?? '', $koneksi);
    
    // Validasi
    $errors = [];
    
    if (empty($judul)) $errors[] = "Judul buku harus diisi!";
    if (empty($penulis)) $errors[] = "Penulis harus diisi!";
    if ($stok < 1) $errors[] = "Stok minimal 1 buku!";
    
    if (empty($errors)) {
        // Generate kode buku jika kosong
        if (empty($isbn)) {
            $isbn = 'BK' . date('Ymd') . rand(1000, 9999);
        }
        
        $query = "INSERT INTO buku (isbn, judul, penulis, penerbit, tahun_terbit, kategori, rak, stok, status, deskripsi) 
                  VALUES ('$isbn', '$judul', '$penulis', '$penerbit', '$tahun_terbit', '$kategori', '$rak', '$stok', '$status', '$deskripsi')";
        
        if (mysqli_query($koneksi, $query)) {
            $_SESSION['message'] = "Buku berhasil ditambahkan!";
            $_SESSION['message_type'] = 'success';
            header("Location: index.php");
            exit();
        } else {
            $errors[] = "Gagal menambahkan buku: " . mysqli_error($koneksi);
        }
    }
    
    if (!empty($errors)) {
        $_SESSION['message'] = implode("<br>", $errors);
        $_SESSION['message_type'] = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Sistem Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .card { border: none; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        .btn-maroon { background: #800000; color: white; border: none; }
        .btn-maroon:hover { background: #600000; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Header -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm mb-4">
            <div class="container">
                <a class="navbar-brand text-danger fw-bold" href="#">
                    <i class="fas fa-book me-2"></i>Perpustakaan UTR
                </a>
                <div class="d-flex align-items-center">
                    <span class="me-3"><?php echo $_SESSION['nama'] ?? 'User'; ?></span>
                    <a href="../../logout.php" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Content -->
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="text-danger"><i class="fas fa-book-medical me-2"></i><?php echo $page_title; ?></h2>
                    <p class="text-muted"><?php echo $page_subtitle; ?></p>
                </div>
                <a href="index.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i>Kembali
                </a>
            </div>
            
            <!-- Pesan -->
            <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['message_type'] ?? 'info'; ?> alert-dismissible fade show">
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php 
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            endif; 
            ?>
            
            <!-- Form -->
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Judul Buku *</label>
                                <input type="text" name="judul" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Penulis *</label>
                                <input type="text" name="penulis" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Penerbit</label>
                                <input type="text" name="penerbit" class="form-control">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Tahun Terbit</label>
                                <input type="number" name="tahun_terbit" class="form-control" value="<?php echo date('Y'); ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Kategori</label>
                                <select name="kategori" class="form-select">
                                    <option value="">Pilih Kategori</option>
                                    <option value="Teknologi">Teknologi</option>
                                    <option value="Sains">Sains</option>
                                    <option value="Sastra">Sastra</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">ISBN (optional)</label>
                                <input type="text" name="isbn" class="form-control">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Rak</label>
                                <input type="text" name="rak" class="form-control">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Stok *</label>
                                <input type="number" name="stok" class="form-control" value="1" min="1" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" rows="3"></textarea>
                        </div>
                        
                        <div class="text-end">
                            <button type="submit" class="btn btn-maroon">
                                <i class="fas fa-save me-2"></i>Simpan Buku
                            </button>
                            <a href="index.php" class="btn btn-secondary ms-2">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>