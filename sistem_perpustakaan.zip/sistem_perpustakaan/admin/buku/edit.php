<?php
// admin/buku/edit_simple.php
session_start();

// Koneksi langsung
$koneksi = mysqli_connect('localhost', 'root', '', 'sistem_perpustakaan');
if (!$koneksi) die("Database error");

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login.php");
    exit();
}

// Fungsi sanitasi sederhana
function sanitize($data, $koneksi) {
    if (!isset($data)) return '';
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($koneksi, $data);
}

// Ambil ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['message'] = "ID tidak valid!";
    $_SESSION['message_type'] = 'error';
    header("Location: index.php");
    exit();
}

$id = intval($_GET['id']);

// Ambil data buku
$query = "SELECT * FROM buku WHERE id = $id";
$result = mysqli_query($koneksi, $query);
$buku = mysqli_fetch_assoc($result);

if (!$buku) {
    $_SESSION['message'] = "Buku tidak ditemukan!";
    $_SESSION['message_type'] = 'error';
    header("Location: index.php");
    exit();
}

// Proses update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $isbn = sanitize($_POST['isbn'] ?? '', $koneksi);
    $judul = sanitize($_POST['judul'] ?? '', $koneksi);
    $penulis = sanitize($_POST['penulis'] ?? '', $koneksi);
    $penerbit = sanitize($_POST['penerbit'] ?? '', $koneksi);
    $tahun_terbit = sanitize($_POST['tahun_terbit'] ?? '', $koneksi);
    $kategori = sanitize($_POST['kategori'] ?? '', $koneksi);
    $rak = sanitize($_POST['rak'] ?? '', $koneksi);
    $stok = intval($_POST['stok'] ?? 0);
    $status = sanitize($_POST['status'] ?? 'tersedia', $koneksi);
    $deskripsi = sanitize($_POST['deskripsi'] ?? '', $koneksi);
    
    // Validasi
    $errors = [];
    if (empty($judul)) $errors[] = "Judul harus diisi!";
    if (empty($penulis)) $errors[] = "Penulis harus diisi!";
    if ($stok < 0) $errors[] = "Stok tidak boleh negatif!";
    
    if (empty($errors)) {
        $query = "UPDATE buku SET 
                  isbn = '$isbn',
                  judul = '$judul',
                  penulis = '$penulis',
                  penerbit = '$penerbit',
                  tahun_terbit = '$tahun_terbit',
                  kategori = '$kategori',
                  rak = '$rak',
                  stok = '$stok',
                  status = '$status',
                  deskripsi = '$deskripsi'
                  WHERE id = $id";
        
        if (mysqli_query($koneksi, $query)) {
            $_SESSION['message'] = "Buku berhasil diperbarui!";
            $_SESSION['message_type'] = 'success';
            header("Location: index.php");
            exit();
        } else {
            $errors[] = "Error: " . mysqli_error($koneksi);
        }
    }
    
    if (!empty($errors)) {
        $_SESSION['message'] = implode("<br>", $errors);
        $_SESSION['message_type'] = 'error';
    }
}

// Set judul halaman
$page_title = "Edit Buku - " . htmlspecialchars($buku['judul']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .card { border: none; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        .btn-maroon { background: #800000; color: white; border: none; }
        .btn-maroon:hover { background: #600000; }
        .form-label { font-weight: 500; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Header -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm mb-4">
            <div class="container">
                <a class="navbar-brand text-danger fw-bold" href="../index.php">
                    <i class="fas fa-book me-2"></i>Perpustakaan UTR
                </a>
                <div class="d-flex align-items-center">
                    <span class="me-3"><?php echo $_SESSION['nama'] ?? 'User'; ?> (<?php echo $_SESSION['role'] ?? 'Guest'; ?>)</span>
                    <a href="../../logout.php" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Content -->
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="text-danger"><i class="fas fa-edit me-2"></i>Edit Buku</h2>
                    <p class="text-muted">Edit data buku: <?php echo htmlspecialchars($buku['judul']); ?></p>
                </div>
                <div>
                    <a href="index.php" class="btn btn-outline-secondary me-2">
                        <i class="fas fa-arrow-left me-2"></i>Kembali
                    </a>
                    <a href="view.php?id=<?php echo $id; ?>" class="btn btn-outline-info">
                        <i class="fas fa-eye me-2"></i>Lihat
                    </a>
                </div>
            </div>
            
            <!-- Pesan -->
            <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?php echo $_SESSION['message_type'] ?? 'info'; ?> alert-dismissible fade show">
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php 
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
            endif; 
            ?>
            
            <!-- Form -->
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Judul Buku *</label>
                                <input type="text" name="judul" class="form-control" 
                                       value="<?php echo htmlspecialchars($buku['judul']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Penulis *</label>
                                <input type="text" name="penulis" class="form-control" 
                                       value="<?php echo htmlspecialchars($buku['penulis']); ?>" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Penerbit</label>
                                <input type="text" name="penerbit" class="form-control" 
                                       value="<?php echo htmlspecialchars($buku['penerbit']); ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Tahun Terbit</label>
                                <input type="number" name="tahun_terbit" class="form-control" 
                                       value="<?php echo htmlspecialchars($buku['tahun_terbit']); ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Kategori</label>
                                <select name="kategori" class="form-select">
                                    <option value="">Pilih Kategori</option>
                                    <option value="Teknologi" <?php echo $buku['kategori'] == 'Teknologi' ? 'selected' : ''; ?>>Teknologi</option>
                                    <option value="Sains" <?php echo $buku['kategori'] == 'Sains' ? 'selected' : ''; ?>>Sains</option>
                                    <option value="Sastra" <?php echo $buku['kategori'] == 'Sastra' ? 'selected' : ''; ?>>Sastra</option>
                                    <option value="Pemrograman" <?php echo $buku['kategori'] == 'Pemrograman' ? 'selected' : ''; ?>>Pemrograman</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">ISBN</label>
                                <input type="text" name="isbn" class="form-control" 
                                       value="<?php echo htmlspecialchars($buku['isbn']); ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Rak</label>
                                <input type="text" name="rak" class="form-control" 
                                       value="<?php echo htmlspecialchars($buku['rak']); ?>">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Stok *</label>
                                <input type="number" name="stok" class="form-control" 
                                       value="<?php echo htmlspecialchars($buku['stok']); ?>" min="0" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="tersedia" <?php echo $buku['status'] == 'tersedia' ? 'selected' : ''; ?>>Tersedia</option>
                                <option value="dipinjam" <?php echo $buku['status'] == 'dipinjam' ? 'selected' : ''; ?>>Dipinjam</option>
                                <option value="hilang" <?php echo $buku['status'] == 'hilang' ? 'selected' : ''; ?>>Hilang</option>
                                <option value="rusak" <?php echo $buku['status'] == 'rusak' ? 'selected' : ''; ?>>Rusak</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" rows="3"><?php echo htmlspecialchars($buku['deskripsi']); ?></textarea>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            ID Buku: <strong><?php echo $id; ?></strong> | 
                            Dibuat: <?php echo date('d/m/Y H:i', strtotime($buku['created_at'])); ?>
                        </div>
                        
                        <div class="text-end">
                            <button type="submit" class="btn btn-maroon">
                                <i class="fas fa-save me-2"></i>Simpan Perubahan
                            </button>
                            <a href="index.php" class="btn btn-secondary ms-2">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validasi form
        document.querySelector('form').addEventListener('submit', function(e) {
            const judul = document.querySelector('input[name="judul"]').value.trim();
            const penulis = document.querySelector('input[name="penulis"]').value.trim();
            const stok = document.querySelector('input[name="stok"]').value;
            
            if (judul === '') {
                e.preventDefault();
                alert('Judul buku harus diisi!');
                return false;
            }
            
            if (penulis === '') {
                e.preventDefault();
                alert('Penulis harus diisi!');
                return false;
            }
            
            if (stok < 0) {
                e.preventDefault();
                alert('Stok tidak boleh negatif!');
                return false;
            }
        });
    </script>
</body>
</html>