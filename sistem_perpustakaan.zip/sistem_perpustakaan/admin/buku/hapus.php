<?php
// admin/buku/hapus.php
session_start();

// Path ke koneksi.php
$koneksi_path = __DIR__ . '/../../koneksi.php';

if (!file_exists($koneksi_path)) {
    die("ERROR: File koneksi.php tidak ditemukan!");
}

require_once $koneksi_path;

// DEFINE FUNCTIONS JIKA BELUM ADA
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
}

if (!function_exists('redirect')) {
    function redirect($url) {
        header("Location: $url");
        exit();
    }
}

if (!function_exists('set_message')) {
    function set_message($message, $type = 'success') {
        $_SESSION['message'] = $message;
        $_SESSION['message_type'] = $type;
    }
}

if (!function_exists('clean_input')) {
    function clean_input($data) {
        global $koneksi;
        if (!isset($data) || $data === null) {
            return '';
        }
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return mysqli_real_escape_string($koneksi, $data);
    }
}

// Cek login
if (!is_logged_in()) {
    $_SESSION['message'] = "Silakan login terlebih dahulu!";
    $_SESSION['message_type'] = 'error';
    redirect('../../login.php');
}

// Cek apakah ada parameter id
if (!isset($_GET['id']) || empty($_GET['id'])) {
    set_message("ID buku tidak valid!", 'error');
    redirect('index.php');
}

$id = intval($_GET['id']); // Gunakan intval untuk keamanan

// Cek apakah buku ada
$query_check = "SELECT * FROM buku WHERE id = $id";
$result_check = mysqli_query($koneksi, $query_check);

if (!$result_check || mysqli_num_rows($result_check) == 0) {
    set_message("Buku tidak ditemukan!", 'error');
    redirect('index.php');
}

// Cek apakah buku sedang dipinjam (jika tabel peminjaman ada)
$total_pinjam = 0;
$query_pinjam = "SELECT COUNT(*) as total FROM peminjaman WHERE buku_id = $id AND status IN ('dipinjam', 'terlambat')";
$result_pinjam = mysqli_query($koneksi, $query_pinjam);
if ($result_pinjam) {
    $total_pinjam = mysqli_fetch_assoc($result_pinjam)['total'];
}

if ($total_pinjam > 0) {
    set_message("Buku tidak dapat dihapus karena masih dipinjam!", 'error');
    redirect('index.php');
}

// Hapus data
$query = "DELETE FROM buku WHERE id = $id";

if (mysqli_query($koneksi, $query)) {
    set_message("Buku berhasil dihapus!", 'success');
} else {
    set_message("Gagal menghapus buku: " . mysqli_error($koneksi), 'error');
}

redirect('index.php');
?>