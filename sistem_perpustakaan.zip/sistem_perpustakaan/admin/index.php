<?php
$page_title = "Dashboard";
$page_subtitle = "Sistem Manajemen Perpustakaan UTR";
require_once 'header.php';
require_once '../koneksi.php';

// Ambil statistik
$stats = array();

// Total Buku
$query_buku = "SELECT COUNT(*) as total FROM buku";
$result_buku = mysqli_query($koneksi, $query_buku);
$stats['total_buku'] = mysqli_fetch_assoc($result_buku)['total'];

// Buku Tersedia
$query_tersedia = "SELECT COUNT(*) as total FROM buku WHERE status = 'tersedia'";
$result_tersedia = mysqli_query($koneksi, $query_tersedia);
$stats['buku_tersedia'] = mysqli_fetch_assoc($result_tersedia)['total'];

// Total Anggota
$query_anggota = "SELECT COUNT(*) as total FROM anggota WHERE status = 'aktif'";
$result_anggota = mysqli_query($koneksi, $query_anggota);
$stats['total_anggota'] = mysqli_fetch_assoc($result_anggota)['total'];

// Peminjaman Aktif
$query_peminjaman = "SELECT COUNT(*) as total FROM peminjaman WHERE status IN ('berjalan', 'terlambat')";
$result_peminjaman = mysqli_query($koneksi, $query_peminjaman);
$stats['peminjaman_aktif'] = mysqli_fetch_assoc($result_peminjaman)['total'];

// Total Denda
$query_denda = "SELECT SUM(jumlah) as total FROM denda WHERE status = 'belum_lunas'";
$result_denda = mysqli_query($koneksi, $query_denda);
$stats['total_denda'] = mysqli_fetch_assoc($result_denda)['total'] ?? 0;

// Peminjaman Terbaru
$query_peminjaman_baru = "SELECT p.*, a.nama as nama_anggota, b.judul as judul_buku 
                         FROM peminjaman p
                         JOIN anggota a ON p.anggota_id = a.id
                         JOIN buku b ON p.buku_id = b.id
                         ORDER BY p.created_at DESC LIMIT 5";
$result_peminjaman_baru = mysqli_query($koneksi, $query_peminjaman_baru);

// Buku Populer
$query_buku_populer = "SELECT b.*, COUNT(p.id) as jumlah_pinjam 
                      FROM buku b
                      LEFT JOIN peminjaman p ON b.id = p.buku_id
                      GROUP BY b.id
                      ORDER BY jumlah_pinjam DESC, b.judul ASC
                      LIMIT 5";
$result_buku_populer = mysqli_query($koneksi, $query_buku_populer);
?>

<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-book"></i>
            </div>
            <div class="stat-number"><?php echo number_format($stats['total_buku']); ?></div>
            <div class="stat-label">Total Buku</div>
        </div>
    </div>
    
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-book-open"></i>
            </div>
            <div class="stat-number"><?php echo number_format($stats['buku_tersedia']); ?></div>
            <div class="stat-label">Buku Tersedia</div>
        </div>
    </div>
    
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-number"><?php echo number_format($stats['total_anggota']); ?></div>
            <div class="stat-label">Anggota Aktif</div>
        </div>
    </div>
    
    <div class="col-md-3 mb-3">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-exchange-alt"></i>
            </div>
            <div class="stat-number"><?php echo number_format($stats['peminjaman_aktif']); ?></div>
            <div class="stat-label">Peminjaman Aktif</div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Peminjaman Terbaru -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-history me-2"></i>Peminjaman Terbaru
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Kode</th>
                                <th>Anggota</th>
                                <th>Buku</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result_peminjaman_baru) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($result_peminjaman_baru)): ?>
                                    <tr>
                                        <td><strong><?php echo $row['kode_peminjaman']; ?></strong></td>
                                        <td><?php echo $row['nama_anggota']; ?></td>
                                        <td><?php echo substr($row['judul_buku'], 0, 30) . '...'; ?></td>
                                        <td>
                                            <?php 
                                            $status_class = '';
                                            switch($row['status']) {
                                                case 'berjalan': $status_class = 'badge-primary'; break;
                                                case 'selesai': $status_class = 'badge-success'; break;
                                                case 'terlambat': $status_class = 'badge-danger'; break;
                                                default: $status_class = 'badge-warning';
                                            }
                                            ?>
                                            <span class="badge <?php echo $status_class; ?>">
                                                <?php echo ucfirst($row['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">Belum ada data peminjaman</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-end mt-3">
                    <a href="peminjaman/index.php" class="btn btn-maroon btn-sm">
                        <i class="fas fa-eye me-1"></i>Lihat Semua
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Buku Populer -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-chart-line me-2"></i>Buku Terpopuler
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Judul Buku</th>
                                <th>Penulis</th>
                                <th>Stok</th>
                                <th>Dipinjam</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result_buku_populer) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($result_buku_populer)): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo substr($row['judul'], 0, 25) . '...'; ?></strong><br>
                                            <small class="text-muted"><?php echo $row['isbn']; ?></small>
                                        </td>
                                        <td><?php echo $row['penulis']; ?></td>
                                        <td>
                                            <span class="badge <?php echo $row['stok'] > 0 ? 'badge-success' : 'badge-danger'; ?>">
                                                <?php echo $row['stok']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo $row['jumlah_pinjam']; ?>x</span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center">Belum ada data buku</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-end mt-3">
                    <a href="buku/index.php" class="btn btn-maroon btn-sm">
                        <i class="fas fa-book me-1"></i>Lihat Koleksi
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <!-- Quick Actions -->
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-bolt me-2"></i>Aksi Cepat
                </h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-3">
                        <a href="buku/tambah.php" class="btn btn-outline-maroon w-100">
                            <i class="fas fa-plus-circle me-2"></i>Tambah Buku
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="anggota/tambah.php" class="btn btn-outline-maroon w-100">
                            <i class="fas fa-user-plus me-2"></i>Tambah Anggota
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="peminjaman/tambah.php" class="btn btn-outline-maroon w-100">
                            <i class="fas fa-exchange-alt me-2"></i>Peminjaman Baru
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="laporan.php" class="btn btn-outline-maroon w-100">
                            <i class="fas fa-file-pdf me-2"></i>Buat Laporan
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>