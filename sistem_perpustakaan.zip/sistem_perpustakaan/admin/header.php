<?php
// ===============================
// START SESSION
// ===============================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ===============================
// CEK LOGIN
// ===============================
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

// ===============================
// KONEKSI DATABASE
// ===============================
require_once __DIR__ . '/../koneksi.php';

// ===============================
// HELPER FUNCTIONS
// ===============================
if (!function_exists('clean_input')) {
    function clean_input($data) {
        global $koneksi;
        $data = trim($data);
        if ($koneksi) {
            $data = mysqli_real_escape_string($koneksi, $data);
        }
        return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('tgl_indo')) {
    function tgl_indo($tanggal) {
        if (empty($tanggal) || $tanggal === '0000-00-00') return '-';

        $bulan = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];

        $pecah = explode('-', date('Y-m-d', strtotime($tanggal)));

        return $pecah[2] . ' ' . $bulan[(int)$pecah[1]] . ' ' . $pecah[0];
    }
}

if (!function_exists('set_message')) {
    function set_message($message, $type = 'info') {
        $_SESSION['flash_message'] = [
            'message' => $message,
            'type'    => $type
        ];
    }
}

if (!function_exists('show_message')) {
    function show_message() {
        if (isset($_SESSION['flash_message'])) {
            $msg = $_SESSION['flash_message'];
            $class = 'alert-info';

            if ($msg['type'] === 'success') $class = 'alert-success';
            if ($msg['type'] === 'error')   $class = 'alert-danger';
            if ($msg['type'] === 'warning') $class = 'alert-warning';

            echo '<div class="alert ' . $class . ' alert-dismissible fade show" role="alert">';
            echo $msg['message'];
            echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
            echo '</div>';

            unset($_SESSION['flash_message']);
        }
    }
}

if (!function_exists('redirect')) {
    function redirect($url) {
        if (!headers_sent()) {
            header("Location: $url");
            exit;
        } else {
            echo "<script>window.location.href = '$url';</script>";
            exit;
        }
    }
}

// ===============================
// FORMAT RUPIAH
// ===============================
if (!function_exists('format_rupiah')) {
    function format_rupiah($angka) {
        return 'Rp ' . number_format((float)$angka, 0, ',', '.');
    }
}

// ===============================
// CEK ADMIN
// ===============================
if (!function_exists('is_admin')) {
    function is_admin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
}

// ===============================
// GENERATE KODE ANGGOTA
// ===============================
if (!function_exists('generate_kode')) {
    function generate_kode($prefix) {
        global $koneksi;

        $prefix = strtoupper($prefix);

        $query = "SELECT kode_anggota 
                  FROM anggota 
                  WHERE kode_anggota LIKE '$prefix%' 
                  ORDER BY kode_anggota DESC 
                  LIMIT 1";

        $result = mysqli_query($koneksi, $query);

        if ($result && $row = mysqli_fetch_assoc($result)) {
            $lastKode = $row['kode_anggota'];
            $number   = (int) substr($lastKode, 3);
            $newNum   = $number + 1;
        } else {
            $newNum = 1;
        }

        return $prefix . str_pad($newNum, 4, '0', STR_PAD_LEFT);
    }
}

// ===============================
// PAGE META DEFAULT
// ===============================
$page_title    = $page_title    ?? 'Dashboard';
$page_subtitle = $page_subtitle ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($page_title); ?> - Sistem Perpustakaan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">

    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <style>
        :root {
            --maroon: #800000;
            --maroon-dark: #5c0000;
            --maroon-light: #a83232;
        }

        body {
            background-color: #f5f6fa;
            font-family: "Segoe UI", Tahoma, sans-serif;
            overflow-x: hidden;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, var(--maroon), var(--maroon-dark));
            min-height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            color: #fff;
            z-index: 100;
            transition: all 0.3s;
        }

        .sidebar .brand {
            padding: 20px;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
            background: rgba(0,0,0,0.1);
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li a {
            display: block;
            padding: 12px 20px;
            color: #fff;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: all 0.3s;
        }

        .sidebar ul li a:hover {
            background: rgba(255,255,255,0.15);
            border-left-color: #fff;
        }

        .sidebar ul li a.active {
            background: rgba(255,255,255,0.2);
            border-left-color: #fff;
        }

        .sidebar ul li a i {
            width: 24px;
            text-align: center;
            margin-right: 10px;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
            min-height: 100vh;
        }

        .topbar {
            background: #fff;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .page-title {
            color: var(--maroon);
            margin: 0;
            font-weight: bold;
            font-size: 1.8rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info .badge {
            background: var(--maroon);
        }

        .btn-maroon {
            background: var(--maroon);
            color: #fff;
            border-radius: 8px;
            border: none;
            padding: 8px 16px;
        }

        .btn-maroon:hover {
            background: var(--maroon-dark);
            color: #fff;
        }

        .card-header {
            background: linear-gradient(180deg, var(--maroon-light), var(--maroon));
            color: #fff;
            font-weight: 600;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        /* Mobile responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .main-content.active {
                margin-left: 250px;
            }
        }

        /* Alert styles */
        .alert {
            border-radius: 10px;
            border: none;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="brand">
        <i class="fas fa-book"></i> Perpustakaan UTR
    </div>

    <ul>
        <li><a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> Dashboard
        </a></li>
        <li><a href="buku/index.php" class="<?php echo strpos($_SERVER['PHP_SELF'], '/buku/') !== false ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> Data Buku
        </a></li>
        <li><a href="anggota/index.php" class="<?php echo strpos($_SERVER['PHP_SELF'], '/anggota/') !== false ? 'active' : ''; ?>">
            <i class="fas fa-users"></i> Data Anggota
        </a></li>
        <li><a href="peminjaman/index.php" class="<?php echo strpos($_SERVER['PHP_SELF'], '/peminjaman/') !== false ? 'active' : ''; ?>">
            <i class="fas fa-handshake"></i> Peminjaman
        </a></li>
        <li><a href="pengembalian/index.php" class="<?php echo strpos($_SERVER['PHP_SELF'], '/pengembalian/') !== false ? 'active' : ''; ?>">
            <i class="fas fa-undo"></i> Pengembalian
        </a></li>
        <li><a href="../logout.php"> <!-- DIUBAH: dari admin/logout.php ke ../logout.php -->
            <i class="fas fa-sign-out-alt"></i> Logout
        </a></li>
    </ul>
</div>

<div class="main-content">
    <div class="topbar">
        <div>
            <h4 class="page-title"><?php echo htmlspecialchars($page_title); ?></h4>
            <?php if (!empty($page_subtitle)) : ?>
                <small class="text-muted"><?php echo htmlspecialchars($page_subtitle); ?></small>
            <?php endif; ?>
        </div>
        <div class="user-info">
            <span class="badge">
                <i class="fas fa-user me-1"></i><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?>
            </span>
            <span class="badge bg-info">
                <?php echo htmlspecialchars($_SESSION['role'] ?? 'Guest'); ?>
            </span>
        </div>
    </div>

    <?php show_message(); ?>