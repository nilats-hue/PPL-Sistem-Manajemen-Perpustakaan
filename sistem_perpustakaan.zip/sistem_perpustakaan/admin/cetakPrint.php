<?php
// Mulai session jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../koneksi.php';

// ========== DEFINISI FUNGSI-FUNGSI YANG DIPERLUKAN ==========

/**
 * Cek apakah user sudah login
 */
function is_logged_in() {
    return isset($_SESSION['id']) && isset($_SESSION['username']);
}

/**
 * Redirect ke URL tertentu
 */
function redirect($url) {
    header("Location: $url");
    exit();
}

/**
 * Membersihkan input dari SQL injection dan XSS
 */
function clean_input($data) {
    global $koneksi;
    if ($koneksi) {
        return mysqli_real_escape_string($koneksi, htmlspecialchars(strip_tags(trim($data))));
    }
    return htmlspecialchars(strip_tags(trim($data)));
}

/**
 * Format tanggal ke Indonesia
 */
function tgl_indo($tanggal) {
    if (empty($tanggal) || $tanggal == '0000-00-00' || $tanggal == '0000-00-00 00:00:00') {
        return '-';
    }
    
    // Jika format datetime, ambil hanya date-nya
    if (strlen($tanggal) > 10) {
        $tanggal = substr($tanggal, 0, 10);
    }
    
    $bulan = array(
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    );
    
    $pecah = explode('-', $tanggal);
    if (count($pecah) != 3) {
        return $tanggal;
    }
    
    return $pecah[2] . ' ' . $bulan[(int)$pecah[1]] . ' ' . $pecah[0];
}

// ========== CEK LOGIN ==========
if (!is_logged_in()) {
    echo "<script>alert('Silakan login terlebih dahulu!'); window.location='../login.php';</script>";
    exit();
}

// ========== AMBIL PARAMETER ==========
$jenis = isset($_GET['type']) ? clean_input($_GET['type']) : (isset($_GET['jenis']) ? clean_input($_GET['jenis']) : 'peminjaman');
$start_date = isset($_GET['start_date']) ? clean_input($_GET['start_date']) : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? clean_input($_GET['end_date']) : date('Y-m-d');
$id = isset($_GET['id']) ? clean_input($_GET['id']) : null;

// ========== SET HEADER UNTUK EXCEL ==========
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"laporan-$jenis-" . date('Ymd-His') . ".xls\"");
header("Cache-Control: max-age=0");
header("Pragma: no-cache");

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; }
        .header { text-align: center; margin-bottom: 30px; }
        .logo { font-size: 24px; font-weight: bold; color: #800000; margin-bottom: 10px; }
        .title { font-size: 20px; font-weight: bold; color: #333; margin-bottom: 5px; }
        .subtitle { font-size: 14px; color: #666; }
        .info { margin-bottom: 20px; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #800000; color: white; padding: 8px; text-align: left; font-weight: bold; border: 1px solid #ddd; }
        td { padding: 8px; border: 1px solid #ddd; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .bold { font-weight: bold; }
        .summary { margin-top: 30px; padding: 10px; background: #f5f5f5; border: 1px solid #ddd; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">UNIVERSITAS TANGERANG RAYA</div>
        <div class="title">LAPORAN PERPUSTAKAAN</div>
        <div class="subtitle">Sistem Manajemen Perpustakaan Digital</div>
    </div>
    
    <div class="info">
        <div>Periode: <?php echo date('d/m/Y', strtotime($start_date)); ?> - <?php echo date('d/m/Y', strtotime($end_date)); ?></div>
        <div>Dicetak pada: <?php echo date('d/m/Y H:i:s'); ?></div>
        <div>Oleh: <?php echo isset($_SESSION['nama']) ? $_SESSION['nama'] : 'Admin'; ?> (<?php echo isset($_SESSION['role']) ? $_SESSION['role'] : 'Administrator'; ?>)</div>
    </div>

<?php
// ========== AMBIL DATA BERDASARKAN JENIS ==========
switch ($jenis) {
    case 'peminjaman':
        echo '<h3 style="color: #800000; text-align: center;">LAPORAN PEMINJAMAN BUKU</h3>';
        
        $query = "SELECT p.*, a.nama as nama_anggota, a.kode_anggota, b.judul as judul_buku, b.isbn 
                 FROM peminjaman p
                 JOIN anggota a ON p.anggota_id = a.id
                 JOIN buku b ON p.buku_id = b.id
                 WHERE p.tanggal_pinjam BETWEEN '$start_date' AND '$end_date'
                 ORDER BY p.tanggal_pinjam DESC";
        $result = mysqli_query($koneksi, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            echo '<table border="1">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Peminjaman</th>
                        <th>Anggota</th>
                        <th>Kode Anggota</th>
                        <th>Buku</th>
                        <th>ISBN</th>
                        <th>Tanggal Pinjam</th>
                        <th>Batas Kembali</th>
                        <th>Tanggal Kembali</th>
                        <th>Status</th>
                        <th>Denda</th>
                    </tr>
                </thead>
                <tbody>';
            
            $no = 1;
            $total_denda = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                    <td>' . $no++ . '</td>
                    <td>' . $row['kode_peminjaman'] . '</td>
                    <td>' . $row['nama_anggota'] . '</td>
                    <td>' . $row['kode_anggota'] . '</td>
                    <td>' . $row['judul_buku'] . '</td>
                    <td>' . ($row['isbn'] ?: '-') . '</td>
                    <td>' . date('d/m/Y', strtotime($row['tanggal_pinjam'])) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['batas_kembali'])) . '</td>
                    <td>' . ($row['tanggal_kembali'] ? date('d/m/Y', strtotime($row['tanggal_kembali'])) : '-') . '</td>
                    <td>' . ucfirst($row['status']) . '</td>
                    <td class="text-right">' . number_format($row['denda'], 0, ',', '.') . '</td>
                </tr>';
                $total_denda += $row['denda'];
            }
            
            echo '</tbody>
                <tfoot>
                    <tr>
                        <td colspan="10" class="text-right bold">Total Denda:</td>
                        <td class="text-right bold">Rp ' . number_format($total_denda, 0, ',', '.') . '</td>
                    </tr>
                    <tr>
                        <td colspan="10" class="text-right bold">Total Transaksi:</td>
                        <td class="text-right bold">' . ($no - 1) . '</td>
                    </tr>
                </tfoot>
            </table>';
        } else {
            echo '<p style="text-align: center;">Tidak ada data peminjaman pada periode ini.</p>';
        }
        break;
        
    case 'anggota':
        echo '<h3 style="color: #800000; text-align: center;">LAPORAN DATA ANGGOTA</h3>';
        
        if ($id) {
            // Cetak detail anggota spesifik
            $query = "SELECT * FROM anggota WHERE id = '$id'";
            $result = mysqli_query($koneksi, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $anggota = mysqli_fetch_assoc($result);
                
                echo '<table border="1" style="width: 80%; margin: 0 auto;">
                    <tr><th colspan="2" style="background: #800000; color: white; text-align: center;">KARTU ANGGOTA</th></tr>
                    <tr><td width="30%"><strong>Kode Anggota</strong></td><td>' . $anggota['kode_anggota'] . '</td></tr>
                    <tr><td><strong>Nama Lengkap</strong></td><td>' . $anggota['nama'] . '</td></tr>
                    <tr><td><strong>Jenis Kelamin</strong></td><td>' . ($anggota['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan') . '</td></tr>
                    <tr><td><strong>Alamat</strong></td><td>' . $anggota['alamat'] . '</td></tr>
                    <tr><td><strong>Telepon</strong></td><td>' . ($anggota['telepon'] ?: '-') . '</td></tr>
                    <tr><td><strong>Email</strong></td><td>' . ($anggota['email'] ?: '-') . '</td></tr>
                    <tr><td><strong>Tanggal Daftar</strong></td><td>' . tgl_indo($anggota['tanggal_daftar']) . '</td></tr>
                    <tr><td><strong>Tanggal Expired</strong></td><td>' . tgl_indo($anggota['tanggal_expired']) . '</td></tr>
                    <tr><td><strong>Status</strong></td><td>' . ucfirst($anggota['status']) . '</td></tr>
                    <tr><td colspan="2" style="text-align: center; padding: 20px;">
                        <div style="border: 2px solid #800000; padding: 10px; display: inline-block;">
                            <strong>KARTU ANGGOTA PERPUSTAKAAN UTR</strong><br>
                            Berlaku hingga: ' . tgl_indo($anggota['tanggal_expired']) . '
                        </div>
                    </td></tr>
                </table>';
            } else {
                echo '<p style="text-align: center;">Data anggota tidak ditemukan.</p>';
            }
        } else {
            // Cetak semua anggota
            $query = "SELECT * FROM anggota 
                     WHERE tanggal_daftar BETWEEN '$start_date' AND '$end_date'
                     ORDER BY nama";
            $result = mysqli_query($koneksi, $query);
            
            if ($result && mysqli_num_rows($result) > 0) {
                echo '<table border="1">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Anggota</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Telepon</th>
                            <th>Email</th>
                            <th>Alamat</th>
                            <th>Tanggal Daftar</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>';
                
                $no = 1;
                $aktif = 0;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>
                        <td>' . $no++ . '</td>
                        <td>' . $row['kode_anggota'] . '</td>
                        <td>' . $row['nama'] . '</td>
                        <td>' . ($row['jenis_kelamin'] == 'L' ? 'L' : 'P') . '</td>
                        <td>' . ($row['telepon'] ?: '-') . '</td>
                        <td>' . ($row['email'] ?: '-') . '</td>
                        <td>' . substr($row['alamat'], 0, 30) . '</td>
                        <td>' . date('d/m/Y', strtotime($row['tanggal_daftar'])) . '</td>
                        <td>' . ucfirst($row['status']) . '</td>
                    </tr>';
                    
                    if ($row['status'] == 'aktif') $aktif++;
                }
                
                echo '</tbody>
                    <tfoot>
                        <tr>
                            <td colspan="9">
                                <div class="summary">
                                    <strong>Ringkasan:</strong><br>
                                    Total Anggota: ' . ($no - 1) . '<br>
                                    Aktif: ' . $aktif . '<br>
                                    Nonaktif: ' . (($no - 1) - $aktif) . '
                                </div>
                            </td>
                        </tr>
                    </tfoot>
                </table>';
            } else {
                echo '<p style="text-align: center;">Tidak ada data anggota pada periode ini.</p>';
            }
        }
        break;
        
    case 'buku':
        echo '<h3 style="color: #800000; text-align: center;">KATALOG BUKU PERPUSTAKAAN</h3>';
        
        if ($id) {
            // Cetak detail buku spesifik
            $query = "SELECT * FROM buku WHERE id = '$id'";
            $result = mysqli_query($koneksi, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $buku = mysqli_fetch_assoc($result);
                
                echo '<table border="1" style="width: 80%; margin: 0 auto;">
                    <tr><th colspan="2" style="background: #800000; color: white; text-align: center;">INFORMASI BUKU</th></tr>
                    <tr><td width="30%"><strong>ISBN</strong></td><td>' . ($buku['isbn'] ?: '-') . '</td></tr>
                    <tr><td><strong>Judul Buku</strong></td><td>' . $buku['judul'] . '</td></tr>
                    <tr><td><strong>Penulis</strong></td><td>' . $buku['penulis'] . '</td></tr>
                    <tr><td><strong>Penerbit</strong></td><td>' . ($buku['penerbit'] ?: '-') . '</td></tr>
                    <tr><td><strong>Tahun Terbit</strong></td><td>' . $buku['tahun_terbit'] . '</td></tr>
                    <tr><td><strong>Kategori</strong></td><td>' . ($buku['kategori'] ?: '-') . '</td></tr>
                    <tr><td><strong>Rak</strong></td><td>' . ($buku['rak'] ?: '-') . '</td></tr>
                    <tr><td><strong>Stok</strong></td><td>' . $buku['stok'] . '</td></tr>
                    <tr><td><strong>Status</strong></td><td>' . ucfirst($buku['status']) . '</td></tr>
                    <tr><td><strong>Deskripsi</strong></td><td>' . ($buku['deskripsi'] ?: '-') . '</td></tr>
                </table>';
            } else {
                echo '<p style="text-align: center;">Data buku tidak ditemukan.</p>';
            }
        } else {
            // Cetak semua buku
            $query = "SELECT * FROM buku ORDER BY judul";
            $result = mysqli_query($koneksi, $query);
            
            if ($result && mysqli_num_rows($result) > 0) {
                echo '<table border="1">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ISBN</th>
                            <th>Judul Buku</th>
                            <th>Penulis</th>
                            <th>Penerbit</th>
                            <th>Tahun</th>
                            <th>Kategori</th>
                            <th>Rak</th>
                            <th>Stok</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>';
                
                $no = 1;
                $total_stok = 0;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<tr>
                        <td>' . $no++ . '</td>
                        <td>' . ($row['isbn'] ?: '-') . '</td>
                        <td>' . $row['judul'] . '</td>
                        <td>' . $row['penulis'] . '</td>
                        <td>' . ($row['penerbit'] ?: '-') . '</td>
                        <td>' . $row['tahun_terbit'] . '</td>
                        <td>' . ($row['kategori'] ?: '-') . '</td>
                        <td>' . ($row['rak'] ?: '-') . '</td>
                        <td class="text-right">' . $row['stok'] . '</td>
                        <td>' . ucfirst($row['status']) . '</td>
                    </tr>';
                    $total_stok += $row['stok'];
                }
                
                echo '</tbody>
                    <tfoot>
                        <tr>
                            <td colspan="8" class="text-right bold">Total Stok:</td>
                            <td class="text-right bold">' . $total_stok . '</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="8" class="text-right bold">Total Judul:</td>
                            <td class="text-right bold">' . ($no - 1) . '</td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>';
            } else {
                echo '<p style="text-align: center;">Tidak ada data buku.</p>';
            }
        }
        break;
        
    case 'denda':
        echo '<h3 style="color: #800000; text-align: center;">LAPORAN DENDA</h3>';
        
        $query = "SELECT d.*, a.nama as nama_anggota, a.kode_anggota, p.kode_peminjaman 
                 FROM denda d
                 JOIN anggota a ON d.anggota_id = a.id
                 LEFT JOIN peminjaman p ON d.peminjaman_id = p.id
                 WHERE (d.created_at BETWEEN '$start_date' AND '$end_date')
                 ORDER BY d.created_at DESC";
        $result = mysqli_query($koneksi, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            echo '<table border="1">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Peminjaman</th>
                        <th>Anggota</th>
                        <th>Kode Anggota</th>
                        <th>Jumlah Denda</th>
                        <th>Status</th>
                        <th>Tanggal Bayar</th>
                        <th>Keterangan</th>
                        <th>Tanggal Input</th>
                    </tr>
                </thead>
                <tbody>';
            
            $no = 1;
            $total_denda = 0;
            $belum_lunas = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                    <td>' . $no++ . '</td>
                    <td>' . ($row['kode_peminjaman'] ?: '-') . '</td>
                    <td>' . $row['nama_anggota'] . '</td>
                    <td>' . $row['kode_anggota'] . '</td>
                    <td class="text-right">Rp ' . number_format($row['jumlah'], 0, ',', '.') . '</td>
                    <td>' . ucfirst($row['status']) . '</td>
                    <td>' . ($row['tanggal_bayar'] ? date('d/m/Y', strtotime($row['tanggal_bayar'])) : '-') . '</td>
                    <td>' . ($row['keterangan'] ?: '-') . '</td>
                    <td>' . date('d/m/Y', strtotime($row['created_at'])) . '</td>
                </tr>';
                $total_denda += $row['jumlah'];
                if ($row['status'] == 'belum_lunas') $belum_lunas++;
            }
            
            echo '</tbody>
                <tfoot>
                    <tr>
                        <td colspan="4" class="text-right bold">Total Denda:</td>
                        <td class="text-right bold">Rp ' . number_format($total_denda, 0, ',', '.') . '</td>
                        <td colspan="4"></td>
                    </tr>
                    <tr>
                        <td colspan="4" class="text-right bold">Belum Lunas:</td>
                        <td class="text-right bold">' . $belum_lunas . ' data</td>
                        <td colspan="4"></td>
                    </tr>
                </tfoot>
            </table>';
        } else {
            echo '<p style="text-align: center;">Tidak ada data denda pada periode ini.</p>';
        }
        break;
        
    case 'pengembalian':
        echo '<h3 style="color: #800000; text-align: center;">LAPORAN PENGEMBALIAN</h3>';
        
        $query = "SELECT pg.*, p.kode_peminjaman, p.tanggal_pinjam, p.batas_kembali,
                         a.nama as nama_anggota, a.kode_anggota, 
                         b.judul as judul_buku, b.isbn
                  FROM pengembalian pg
                  JOIN peminjaman p ON pg.peminjaman_id = p.id
                  JOIN anggota a ON p.anggota_id = a.id
                  JOIN buku b ON p.buku_id = b.id
                  WHERE pg.tanggal_kembali BETWEEN '$start_date' AND '$end_date'
                  ORDER BY pg.tanggal_kembali DESC";
        $result = mysqli_query($koneksi, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            echo '<table border="1">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Peminjaman</th>
                        <th>Anggota</th>
                        <th>Buku</th>
                        <th>Tanggal Pinjam</th>
                        <th>Batas Kembali</th>
                        <th>Tanggal Kembali</th>
                        <th>Terlambat</th>
                        <th>Denda</th>
                        <th>Kondisi Buku</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>';
            
            $no = 1;
            $total_denda = 0;
            $total_terlambat = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                    <td>' . $no++ . '</td>
                    <td>' . $row['kode_peminjaman'] . '</td>
                    <td>' . $row['nama_anggota'] . '</td>
                    <td>' . substr($row['judul_buku'], 0, 30) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['tanggal_pinjam'])) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['batas_kembali'])) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['tanggal_kembali'])) . '</td>
                    <td class="text-right">' . $row['terlambat_hari'] . ' hari</td>
                    <td class="text-right">Rp ' . number_format($row['denda'], 0, ',', '.') . '</td>
                    <td>' . ucfirst($row['kondisi_buku']) . '</td>
                    <td>' . ($row['catatan'] ?: '-') . '</td>
                </tr>';
                $total_denda += $row['denda'];
                $total_terlambat += $row['terlambat_hari'];
            }
            
            echo '</tbody>
                <tfoot>
                    <tr>
                        <td colspan="7" class="text-right bold">Total Denda:</td>
                        <td class="text-right bold">' . $total_terlambat . ' hari</td>
                        <td class="text-right bold">Rp ' . number_format($total_denda, 0, ',', '.') . '</td>
                        <td colspan="2"></td>
                    </tr>
                    <tr>
                        <td colspan="7" class="text-right bold">Total Pengembalian:</td>
                        <td colspan="4" class="text-right bold">' . ($no - 1) . ' data</td>
                    </tr>
                </tfoot>
            </table>';
        } else {
            echo '<p style="text-align: center;">Tidak ada data pengembalian pada periode ini.</p>';
        }
        break;
        
    default:
        echo '<p style="text-align: center; color: red;">Jenis laporan tidak valid!</p>';
        break;
}

// Tutup koneksi
mysqli_close($koneksi);
?>

    <div style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 10px; color: #666; text-align: center;">
        <p>Dicetak secara otomatis oleh Sistem Manajemen Perpustakaan UTR</p>
        <p>&copy; <?php echo date('Y'); ?> - Universitas Tangerang Raya</p>
    </div>
</body>
</html>