<?php
require_once '../koneksi.php';

// Cek login
if (!is_logged_in()) {
    redirect('../login.php');
}

// Cek hanya admin yang bisa ganti password
if (!is_admin()) {
    echo json_encode(['success' => false, 'message' => 'Akses ditolak!']);
    exit();
}

// Proses AJAX ganti password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'ganti_password') {
    $password_lama = clean_input($_POST['password_lama']);
    $password_baru = clean_input($_POST['password_baru']);
    $konfirmasi_password = clean_input($_POST['konfirmasi_password']);
    
    // Validasi
    if (empty($password_lama) || empty($password_baru) || empty($konfirmasi_password)) {
        echo json_encode(['success' => false, 'message' => 'Semua field harus diisi!']);
        exit();
    }
    
    if (strlen($password_baru) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password baru minimal 6 karakter!']);
        exit();
    }
    
    if ($password_baru != $konfirmasi_password) {
        echo json_encode(['success' => false, 'message' => 'Konfirmasi password tidak cocok!']);
        exit();
    }
    
    // Cek password lama
    $user_id = $_SESSION['user_id'];
    $query_user = "SELECT password FROM users WHERE id = '$user_id'";
    $result_user = mysqli_query($koneksi, $query_user);
    $user = mysqli_fetch_assoc($result_user);
    
    if (!password_verify($password_lama, $user['password'])) {
        echo json_encode(['success' => false, 'message' => 'Password lama salah!']);
        exit();
    }
    
    // Hash password baru
    $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);
    
    // Update password
    $query = "UPDATE users SET password = '$password_hash' WHERE id = '$user_id'";
    
    if (mysqli_query($koneksi, $query)) {
        echo json_encode(['success' => true, 'message' => 'Password berhasil diubah!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal mengubah password!']);
    }
    exit();
}

// Redirect jika akses langsung
redirect('index.php');
?>