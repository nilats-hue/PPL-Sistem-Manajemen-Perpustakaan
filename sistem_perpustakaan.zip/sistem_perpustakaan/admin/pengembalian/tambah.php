<?php
$page_title = "Pengembalian Baru";
$page_subtitle = "Proses pengembalian buku";
require_once '../header.php';
require_once '../../koneksi.php';

// Cek apakah ada parameter peminjaman_id
if (isset($_GET['peminjaman_id'])) {
    $peminjaman_id = clean_input($_GET['peminjaman_id']);
    
    // Ambil data peminjaman
    $query_peminjaman = "SELECT p.*, a.nama as nama_anggota, b.judul as judul_buku 
                        FROM peminjaman p
                        JOIN anggota a ON p.anggota_id = a.id
                        JOIN buku b ON p.buku_id = b.id
                        WHERE p.id = '$peminjaman_id' AND p.status IN ('berjalan', 'terlambat')";
    $result_peminjaman = mysqli_query($koneksi, $query_peminjaman);
    
    if (mysqli_num_rows($result_peminjaman) == 0) {
        set_message("Peminjaman tidak ditemukan atau sudah dikembalikan!", 'error');
        redirect('index.php');
    }
    
    $peminjaman = mysqli_fetch_assoc($result_peminjaman);
}

// Proses pengembalian
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $peminjaman_id = clean_input($_POST['peminjaman_id']);
    $tanggal_kembali = clean_input($_POST['tanggal_kembali']);
    $kondisi_buku = clean_input($_POST['kondisi_buku']);
    $catatan = clean_input($_POST['catatan']);
    
    // Ambil data peminjaman
    $query_pinjam = "SELECT *, DATEDIFF('$tanggal_kembali', batas_kembali) as terlambat_hari 
                     FROM peminjaman WHERE id = '$peminjaman_id'";
    $result_pinjam = mysqli_query($koneksi, $query_pinjam);
    $pinjam = mysqli_fetch_assoc($result_pinjam);
    
    // Hitung denda
    $denda = 0;
    $terlambat_hari = max(0, $pinjam['terlambat_hari']);
    if ($terlambat_hari > 0) {
        $denda = $terlambat_hari * 2000; // Rp 2.000 per hari
    }
    
    // Tambah denda untuk buku rusak/hilang
    if ($kondisi_buku == 'rusak_ringan') {
        $denda += 5000; // Tambah Rp 5.000 untuk rusak ringan
    } elseif ($kondisi_buku == 'rusak_berat') {
        $denda += 20000; // Tambah Rp 20.000 untuk rusak berat
    } elseif ($kondisi_buku == 'hilang') {
        $denda += 50000; // Tambah Rp 50.000 untuk buku hilang
    }
    
    // Mulai transaction
    mysqli_begin_transaction($koneksi);
    
    try {
        // Tambah ke tabel pengembalian
        $query_pengembalian = "INSERT INTO pengembalian (peminjaman_id, tanggal_kembali, terlambat_hari, denda, kondisi_buku, catatan) 
                              VALUES ('$peminjaman_id', '$tanggal_kembali', '$terlambat_hari', '$denda', '$kondisi_buku', '$catatan')";
        mysqli_query($koneksi, $query_pengembalian);
        
        // Update peminjaman
        $query_update = "UPDATE peminjaman SET 
                        tanggal_kembali = '$tanggal_kembali',
                        denda = '$denda',
                        status = 'selesai'
                        WHERE id = '$peminjaman_id'";
        mysqli_query($koneksi, $query_update);
        
        // Update stok dan status buku
        if ($kondisi_buku == 'hilang') {
            // Jika buku hilang, tidak perlu update stok
            $query_buku = "UPDATE buku SET status = 'hilang' WHERE id = '{$pinjam['buku_id']}'";
        } elseif ($kondisi_buku == 'rusak_berat') {
            // Jika rusak berat, status rusak
            $query_buku = "UPDATE buku SET status = 'rusak' WHERE id = '{$pinjam['buku_id']}'";
        } else {
            // Jika baik atau rusak ringan, kembalikan stok
            $query_buku = "UPDATE buku SET stok = stok + 1, status = 'tersedia' WHERE id = '{$pinjam['buku_id']}'";
        }
        mysqli_query($koneksi, $query_buku);
        
        // Jika ada denda, tambah ke tabel denda
        if ($denda > 0) {
            $query_denda = "INSERT INTO denda (anggota_id, peminjaman_id, jumlah, status, keterangan) 
                           VALUES ('{$pinjam['anggota_id']}', '$peminjaman_id', '$denda', 'belum_lunas', 'Denda pengembalian buku')";
            mysqli_query($koneksi, $query_denda);
        }
        
        // Commit transaction
        mysqli_commit($koneksi);
        
        set_message("Buku berhasil dikembalikan!", 'success');
        redirect('index.php');
        
    } catch (Exception $e) {
        // Rollback transaction
        mysqli_rollback($koneksi);
        set_message("Gagal mengembalikan buku: " . $e->getMessage(), 'error');
    }
}
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-undo me-2"></i>Form Pengembalian Buku
                </h5>
            </div>
            <div class="card-body">
                <?php if (isset($peminjaman)): ?>
                <form method="POST" action="">
                    <input type="hidden" name="peminjaman_id" value="<?php echo $peminjaman_id; ?>">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Kode Peminjaman</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo $peminjaman['kode_peminjaman']; ?>" readonly>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Tanggal Kembali</label>
                                <input type="date" name="tanggal_kembali" class="form-control" 
                                       value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Anggota</label>
                        <input type="text" class="form-control" 
                               value="<?php echo $peminjaman['nama_anggota']; ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Buku</label>
                        <input type="text" class="form-control" 
                               value="<?php echo $peminjaman['judul_buku']; ?>" readonly>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Tanggal Pinjam</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo tgl_indo($peminjaman['tanggal_pinjam']); ?>" readonly>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Batas Kembali</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo tgl_indo($peminjaman['batas_kembali']); ?>" readonly>
                            </div>
                        </div>
                    </div>
                    
                    <?php
                    // Hitung keterlambatan
                    $hari_terlambat = max(0, (strtotime(date('Y-m-d')) - strtotime($peminjaman['batas_kembali'])) / 86400);
                    ?>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Keterlambatan</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo $hari_terlambat; ?> hari" readonly>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Denda Keterlambatan</label>
                                <input type="text" class="form-control" 
                                       value="<?php echo format_rupiah($hari_terlambat * 2000); ?>" readonly>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Kondisi Buku <span class="text-danger">*</span></label>
                        <select name="kondisi_buku" class="form-select" required>
                            <option value="baik">Baik</option>
                            <option value="rusak_ringan">Rusak Ringan (+ Rp 5.000)</option>
                            <option value="rusak_berat">Rusak Berat (+ Rp 20.000)</option>
                            <option value="hilang">Hilang (+ Rp 50.000)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Catatan</label>
                        <textarea name="catatan" class="form-control" rows="3" 
                                  placeholder="Masukkan catatan pengembalian"></textarea>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Perhatian!</strong> Pastikan kondisi buku sesuai dengan kenyataan. 
                        Denda akan dihitung otomatis berdasarkan kondisi dan keterlambatan.
                    </div>
                    
                    <div class="form-group mt-4">
                        <button type="submit" class="btn btn-maroon me-2">
                            <i class="fas fa-check-circle me-1"></i>Proses Pengembalian
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i>Batal
                        </a>
                    </div>
                </form>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Pilih peminjaman yang akan dikembalikan dari halaman data peminjaman.
                    </div>
                    <div class="text-center mt-3">
                        <a href="../peminjaman/index.php" class="btn btn-maroon">
                            <i class="fas fa-arrow-left me-1"></i>Ke Data Peminjaman
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../footer.php'; ?>