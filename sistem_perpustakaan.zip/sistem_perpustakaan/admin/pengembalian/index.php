<?php
$page_title = "Pengembalian Buku";
$page_subtitle = "Kelola pengembalian buku";

// HEADER SUDAH INCLUDE koneksi + helper
require_once '../header.php';

// ❌ HAPUS BARIS INI
// require_once '../../koneksi.php';

// Ambil data pengembalian
$query = "SELECT pg.*, p.kode_peminjaman, p.tanggal_pinjam, p.batas_kembali,
                 a.nama as nama_anggota, a.kode_anggota, 
                 b.judul as judul_buku, b.isbn
          FROM pengembalian pg
          JOIN peminjaman p ON pg.peminjaman_id = p.id
          JOIN anggota a ON p.anggota_id = a.id
          JOIN buku b ON p.buku_id = b.id
          ORDER BY pg.created_at DESC";

$result = mysqli_query($koneksi, $query);
?>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title">
            <i class="fas fa-undo me-2"></i>Data Pengembalian Buku
        </h5>
        <div>
            <a href="tambah.php" class="btn btn-maroon">
                <i class="fas fa-plus-circle me-1"></i>Pengembalian Baru
            </a>
            <a href="../cetakPdf.php?type=pengembalian" class="btn btn-outline-maroon ms-2">
                <i class="fas fa-file-pdf me-1"></i>Laporan
            </a>
        </div>
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table datatable">
                <thead>
                    <tr>
                        <th width="50">No</th>
                        <th>Kode Peminjaman</th>
                        <th>Anggota</th>
                        <th>Buku</th>
                        <th>Tanggal Pinjam</th>
                        <th>Tanggal Kembali</th>
                        <th>Terlambat</th>
                        <th>Denda</th>
                        <th>Kondisi</th>
                        <th width="120">Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <?php $no = 1; ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>

                        <?php
                        $tanggal_kembali = $row['tanggal_kembali'] ?? null;
                        $terlambat_hari  = $row['terlambat_hari'] ?? 0;
                        $denda           = $row['denda'] ?? 0;
                        $kondisi         = $row['kondisi_buku'] ?? 'baik';
                        ?>

                        <tr>
                            <td><?php echo $no++; ?></td>

                            <td>
                                <strong class="text-maroon">
                                    <?php echo htmlspecialchars($row['kode_peminjaman']); ?>
                                </strong>
                            </td>

                            <td>
                                <strong><?php echo htmlspecialchars($row['nama_anggota']); ?></strong><br>
                                <small class="text-muted">
                                    <?php echo htmlspecialchars($row['kode_anggota']); ?>
                                </small>
                            </td>

                            <td>
                                <strong><?php echo htmlspecialchars(substr($row['judul_buku'], 0, 25)); ?>...</strong><br>
                                <small class="text-muted">ISBN: <?php echo htmlspecialchars($row['isbn']); ?></small>
                            </td>

                            <td><?php echo tgl_indo($row['tanggal_pinjam']); ?></td>
                            <td><?php echo tgl_indo($tanggal_kembali); ?></td>

                            <td>
                                <?php if ($terlambat_hari > 0): ?>
                                    <span class="badge bg-danger">
                                        <?php echo $terlambat_hari; ?> hari
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-success">Tepat waktu</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if ($denda > 0): ?>
                                    <span class="badge bg-danger">
                                        <?php echo format_rupiah($denda); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php 
                                $kondisi_class = '';
                                switch ($kondisi) {
                                    case 'baik': $kondisi_class = 'badge-success'; break;
                                    case 'rusak_ringan': $kondisi_class = 'badge-warning'; break;
                                    case 'rusak_berat': $kondisi_class = 'badge-danger'; break;
                                    case 'hilang': $kondisi_class = 'badge-dark'; break;
                                    default: $kondisi_class = 'badge-secondary';
                                }

                                $kondisi_text = [
                                    'baik' => 'Baik',
                                    'rusak_ringan' => 'Rusak Ringan',
                                    'rusak_berat' => 'Rusak Berat',
                                    'hilang' => 'Hilang'
                                ];
                                ?>

                                <span class="badge <?php echo $kondisi_class; ?>">
                                    <?php echo $kondisi_text[$kondisi] ?? '-'; ?>
                                </span>
                            </td>

                            <td>
                                <div class="btn-group" role="group">
                                    <a href="../cetakPrint.php?type=pengembalian&id=<?php echo $row['id']; ?>" 
                                       class="btn btn-view btn-action" target="_blank">
                                        <i class="fas fa-print"></i>
                                    </a>

                                    <?php if (is_admin()): ?>
                                    <a href="aksi.php?hapus=<?php echo $row['id']; ?>" 
                                       class="btn btn-delete btn-action confirm-delete">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>

                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center">
                                Belum ada data pengembalian
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>

<?php require_once '../footer.php'; ?>
