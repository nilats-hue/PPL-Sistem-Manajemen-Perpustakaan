<?php
require_once '../../koneksi.php';

// Cek login
if (!is_logged_in()) {
    redirect('../../login.php');
}

// Proses hapus pengembalian (hanya admin)
if (isset($_GET['hapus']) && is_admin()) {
    $id = clean_input($_GET['hapus']);
    
    // Cek apakah pengembalian ada
    $query_check = "SELECT pg.*, p.buku_id 
                   FROM pengembalian pg
                   JOIN peminjaman p ON pg.peminjaman_id = p.id
                   WHERE pg.id = '$id'";
    $result_check = mysqli_query($koneksi, $query_check);
    
    if (mysqli_num_rows($result_check) == 0) {
        set_message("Data pengembalian tidak ditemukan!", 'error');
        redirect('index.php');
    }
    
    $pengembalian = mysqli_fetch_assoc($result_check);
    
    // Mulai transaction
    mysqli_begin_transaction($koneksi);
    
    try {
        // Kembalikan status peminjaman
        $query_peminjaman = "UPDATE peminjaman SET 
                            tanggal_kembali = NULL,
                            denda = 0,
                            status = 'berjalan'
                            WHERE id = '{$pengembalian['peminjaman_id']}'";
        mysqli_query($koneksi, $query_peminjaman);
        
        // Kurangi stok buku (kembalikan ke keadaan sebelum pengembalian)
        $query_buku = "UPDATE buku SET stok = stok - 1 WHERE id = '{$pengembalian['buku_id']}'";
        mysqli_query($koneksi, $query_buku);
        
        // Hapus data denda terkait
        $query_denda = "DELETE FROM denda WHERE peminjaman_id = '{$pengembalian['peminjaman_id']}'";
        mysqli_query($koneksi, $query_denda);
        
        // Hapus pengembalian
        $query = "DELETE FROM pengembalian WHERE id = '$id'";
        mysqli_query($koneksi, $query);
        
        // Commit transaction
        mysqli_commit($koneksi);
        
        set_message("Data pengembalian berhasil dihapus!", 'success');
        
    } catch (Exception $e) {
        // Rollback transaction
        mysqli_rollback($koneksi);
        set_message("Gagal menghapus data: " . $e->getMessage(), 'error');
    }
    
    redirect('index.php');
}
?>