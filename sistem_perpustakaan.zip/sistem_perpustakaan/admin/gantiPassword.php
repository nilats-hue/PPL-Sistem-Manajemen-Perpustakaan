<?php
$page_title = "Ganti Password";
$page_subtitle = "Ubah password akun Anda";
require_once 'header.php';
require_once '../koneksi.php';

// Cek hanya admin yang bisa ganti password
if (!is_admin()) {
    set_message("Anda tidak memiliki akses untuk halaman ini!", 'error');
    redirect('index.php');
}

// Proses ganti password
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password_lama = clean_input($_POST['password_lama']);
    $password_baru = clean_input($_POST['password_baru']);
    $konfirmasi_password = clean_input($_POST['konfirmasi_password']);
    
    // Validasi
    $errors = array();
    
    if (empty($password_lama)) {
        $errors[] = "Password lama harus diisi!";
    }
    
    if (empty($password_baru)) {
        $errors[] = "Password baru harus diisi!";
    }
    
    if (strlen($password_baru) < 6) {
        $errors[] = "Password baru minimal 6 karakter!";
    }
    
    if ($password_baru != $konfirmasi_password) {
        $errors[] = "Konfirmasi password tidak cocok!";
    }
    
    if (empty($errors)) {
        // Cek password lama
        $user_id = $_SESSION['user_id'];
        $query_user = "SELECT password FROM users WHERE id = '$user_id'";
        $result_user = mysqli_query($koneksi, $query_user);
        $user = mysqli_fetch_assoc($result_user);
        
        if (!password_verify($password_lama, $user['password'])) {
            $errors[] = "Password lama salah!";
        }
    }
    
    if (empty($errors)) {
        // Hash password baru
        $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);
        
        // Update password
        $query = "UPDATE users SET password = '$password_hash' WHERE id = '$user_id'";
        
        if (mysqli_query($koneksi, $query)) {
            set_message("Password berhasil diubah!", 'success');
            redirect('index.php');
        } else {
            set_message("Gagal mengubah password: " . mysqli_error($koneksi), 'error');
        }
    } else {
        set_message(implode("<br>", $errors), 'error');
    }
}
?>

<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-key me-2"></i>Form Ganti Password
                </h5>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Perhatian:</strong> Password harus minimal 6 karakter dan sebaiknya kombinasi huruf dan angka.
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password Lama <span class="text-danger">*</span></label>
                        <input type="password" name="password_lama" class="form-control" 
                               placeholder="Masukkan password lama" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password Baru <span class="text-danger">*</span></label>
                        <input type="password" name="password_baru" class="form-control" 
                               placeholder="Masukkan password baru (min. 6 karakter)" required>
                        <small class="text-muted">Minimal 6 karakter</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Konfirmasi Password Baru <span class="text-danger">*</span></label>
                        <input type="password" name="konfirmasi_password" class="form-control" 
                               placeholder="Ulangi password baru" required>
                    </div>
                    
                    <div class="form-group mt-4">
                        <button type="submit" class="btn btn-maroon me-2">
                            <i class="fas fa-save me-1"></i>Simpan Password
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i>Batal
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Toggle password visibility
    $('input[type="password"]').each(function() {
        var input = $(this);
        var icon = $('<i class="fas fa-eye toggle-password"></i>').css({
            'position': 'absolute',
            'right': '15px',
            'top': '50%',
            'transform': 'translateY(-50%)',
            'cursor': 'pointer',
            'color': '#666'
        });
        
        var wrapper = $('<div style="position: relative;"></div>');
        input.wrap(wrapper);
        input.after(icon);
        
        icon.on('click', function() {
            var type = input.attr('type') === 'password' ? 'text' : 'password';
            input.attr('type', type);
            $(this).toggleClass('fa-eye fa-eye-slash');
        });
    });
});
</script>

<?php require_once 'footer.php'; ?>