<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../koneksi.php';

// ===============================
// HELPER FUNCTIONS ONLY
// ===============================
function set_message($message, $type = 'info') {
    $_SESSION['flash_message'] = [
        'message' => $message,
        'type'    => $type
    ];
}

function redirect($url) {
    header("Location: $url");
    exit;
}
