<?php
session_start();

// Hapus semua session
session_unset();
session_destroy();

// Redirect ke login yang ada di root project
header("Location: login.php"); // DIUBAH: dari ../login.php ke login.php
exit();
?>