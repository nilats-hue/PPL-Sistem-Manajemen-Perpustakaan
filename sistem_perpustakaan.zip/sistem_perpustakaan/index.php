<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Manajemen Perpustakaan - UTR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --maroon: #800000;
            --maroon-dark: #600000;
            --maroon-light: #a52a2a;
            --white: #ffffff;
            --light: #f8f9fa;
            --gray: #6c757d;
            --dark: #343a40;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            min-height: 100vh;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: var(--maroon) !important;
            font-size: 1.5rem;
        }
        
        .nav-link {
            color: var(--dark) !important;
            font-weight: 500;
            transition: color 0.3s;
        }
        
        .nav-link:hover {
            color: var(--maroon) !important;
        }
        
        /* PERBAIKAN: Class untuk warna maroon */
        .text-maroon {
            color: var(--maroon) !important;
        }
        
        .bg-maroon {
            background-color: var(--maroon) !important;
        }
        
        .btn-maroon {
            background-color: var(--maroon);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-maroon:hover {
            background-color: var(--maroon-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(128, 0, 0, 0.2);
            color: white;
        }
        
        /* PERBAIKAN: Tombol Login lebih jelas */
        .btn-login-hero {
            background-color: white;
            color: var(--maroon) !important;
            border: 2px solid var(--maroon);
            padding: 12px 30px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .btn-login-hero:hover {
            background-color: var(--maroon);
            color: white !important;
            transform: translateY(-2px);
        }
        
        .hero-section {
            background: linear-gradient(rgba(128, 0, 0, 0.9), rgba(96, 0, 0, 0.9));
            color: white;
            padding: 100px 0;
            border-radius: 0 0 30px 30px;
            margin-bottom: 60px;
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: url('https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80');
            background-size: cover;
            background-position: center;
            opacity: 0.3;
            z-index: 0;
        }
        
        .hero-section > .container {
            position: relative;
            z-index: 1;
        }
        
        .hero-title {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .hero-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 30px;
        }
        
        .feature-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            border-top: 5px solid var(--maroon);
            margin-bottom: 30px;
            height: 100%;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(128, 0, 0, 0.15);
        }
        
        .feature-icon {
            font-size: 3rem;
            color: var(--maroon);
            margin-bottom: 20px;
        }
        
        .feature-title {
            color: var(--maroon);
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .stats-section {
            background: var(--maroon);
            color: white;
            padding: 60px 0;
            border-radius: 30px;
            margin: 60px 0;
        }
        
        .stat-number {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .stat-label {
            font-size: 1.2rem;
            opacity: 0.9;
        }
        
        .footer {
            background: var(--dark);
            color: white;
            padding: 40px 0;
            margin-top: 60px;
        }
        
        .footer-title {
            color: var(--maroon-light);
            margin-bottom: 20px;
            font-weight: 600;
        }
        
        .copyright {
            background: rgba(0,0,0,0.2);
            padding: 20px 0;
            margin-top: 40px;
        }
        
        /* PERBAIKAN: Navbar Login Button */
        .nav-login-btn {
            background: white;
            color: var(--maroon) !important;
            border-radius: 8px;
            padding: 8px 20px !important;
            font-weight: 600;
            border: 2px solid var(--maroon);
            margin-left: 10px;
            transition: all 0.3s;
        }
        
        .nav-login-btn:hover {
            background: var(--maroon) !important;
            color: white !important;
        }
        
        /* PERBAIKAN: Link login di hero section */
        .hero-login-btn {
            background: white;
            color: var(--maroon) !important;
            padding: 15px 35px;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 10px;
            text-decoration: none;
            display: inline-block;
            border: 2px solid white;
            transition: all 0.3s;
        }
        
        .hero-login-btn:hover {
            background: transparent;
            color: white !important;
            border-color: white;
        }
        
        .hero-learn-btn {
            background: transparent;
            color: white !important;
            padding: 15px 35px;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 10px;
            text-decoration: none;
            display: inline-block;
            border: 2px solid white;
            transition: all 0.3s;
        }
        
        .hero-learn-btn:hover {
            background: white;
            color: var(--maroon) !important;
        }
        
        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-login-btn, .hero-learn-btn {
                padding: 12px 25px;
                font-size: 1rem;
                margin-bottom: 10px;
                display: block;
                text-align: center;
            }
            
            .nav-login-btn {
                margin-left: 0;
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-book me-2"></i>Perpustakaan UTR
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Fitur</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Tentang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nav-login-btn" href="login.php">
                            <i class="fas fa-sign-in-alt me-1"></i>Login
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-section" style="padding-top: 140px;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="hero-title">Sistem Manajemen Perpustakaan</h1>
                    <p class="hero-subtitle">
                        Universitas Tangerang Raya hadir dengan sistem digital untuk memudahkan pengelolaan koleksi buku, 
                        peminjaman, dan pengembalian dengan lebih efisien dan terstruktur.
                    </p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="login.php" class="hero-login-btn">
                            <i class="fas fa-sign-in-alt me-2"></i>Masuk Sistem
                        </a>
                        <a href="#features" class="hero-learn-btn">
                            <i class="fas fa-info-circle me-2"></i>Pelajari Fitur
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <i class="fas fa-book-open display-1 text-white opacity-75"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-5">
        <div class="container">
            <div class="row mb-5">
                <div class="col-12 text-center">
                    <h2 class="display-5 fw-bold text-maroon">Fitur Unggulan Sistem</h2>
                    <p class="lead text-muted">Sistem kami dilengkapi dengan berbagai fitur canggih untuk pengelolaan perpustakaan yang optimal</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-book"></i>
                        </div>
                        <h3 class="feature-title">Manajemen Buku</h3>
                        <p>Kelola koleksi buku dengan sistem katalog digital, termasuk penambahan, edit, dan penghapusan data buku.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="feature-title">Data Anggota</h3>
                        <p>Kelola data anggota perpustakaan dengan sistem keanggotaan digital yang terintegrasi.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-exchange-alt"></i>
                        </div>
                        <h3 class="feature-title">Peminjaman Buku</h3>
                        <p>Sistem peminjaman dan pengembalian buku dengan pencatatan otomatis dan notifikasi.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <h3 class="feature-title">Laporan Digital</h3>
                        <p>Generate laporan aktivitas perpustakaan dalam format PDF dan Excel untuk analisis data.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-print"></i>
                        </div>
                        <h3 class="feature-title">Cetak Otomatis</h3>
                        <p>Cetak katalog, kartu anggota, dan bukti peminjaman dengan format yang profesional.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3 class="feature-title">Keamanan Data</h3>
                        <p>Sistem keamanan terenkripsi dengan hak akses terpisah untuk admin dan pustakawan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 mb-4 mb-md-0">
                    <div class="stat-number">10,000+</div>
                    <div class="stat-label">Koleksi Buku</div>
                </div>
                <div class="col-md-3 mb-4 mb-md-0">
                    <div class="stat-number">5,000+</div>
                    <div class="stat-label">Anggota Aktif</div>
                </div>
                <div class="col-md-3 mb-4 mb-md-0">
                    <div class="stat-number">1,000+</div>
                    <div class="stat-label">Peminjaman/Bulan</div>
                </div>
                <div class="col-md-3">
                    <div class="stat-number">99%</div>
                    <div class="stat-label">Kepuasan Pengguna</div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h2 class="display-5 fw-bold text-maroon mb-4">Tentang Sistem Kami</h2>
                    <p class="lead mb-4">
                        Sistem Manajemen Perpustakaan Universitas Tangerang Raya dikembangkan untuk mendigitalisasi 
                        seluruh proses pengelolaan perpustakaan, mulai dari katalogisasi buku, manajemen anggota, 
                        hingga transaksi peminjaman dan pengembalian.
                    </p>
                    <p>
                        Dengan sistem ini, pustakawan dapat bekerja lebih efisien, anggota dapat mengakses layanan 
                        dengan mudah, dan manajemen mendapatkan laporan real-time untuk pengambilan keputusan.
                    </p>
                    <a href="login.php" class="btn btn-maroon mt-3">
                        <i class="fas fa-rocket me-2"></i>Coba Sekarang
                    </a>
                </div>
                <div class="col-lg-6">
                    <div class="text-center">
                        <i class="fas fa-laptop-code display-1 text-maroon mb-3"></i>
                        <h4 class="text-maroon">Sistem Digital Terintegrasi</h4>
                        <p class="text-muted">Akses dimanapun dan kapanpun</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h4 class="footer-title">
                        <i class="fas fa-book me-2"></i>Perpustakaan UTR
                    </h4>
                    <p>
                        Sistem Manajemen Perpustakaan Digital Universitas Tangerang Raya.
                        Mengubah cara tradisional menjadi digital untuk efisiensi yang lebih baik.
                    </p>
                </div>
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h4 class="footer-title">Kontak Kami</h4>
                    <p><i class="fas fa-map-marker-alt me-2"></i>Jl. Perumahan Sudirman Indah No.Blok E, Tigaraksa, Kabupaten Tangerang, Banten 15720</p>
                    <p><i class="fas fa-phone me-2"></i>0851-3541-3995</p>
                    <p><i class="fas fa-envelope me-2"></i>perpustakaan@utr.ac.id</p>
                </div>
                <div class="col-lg-4">
                    <h4 class="footer-title">Jam Operasional</h4>
                    <p>Senin - Jumat: 08:00 - 17:00</p>
                    <p>Sabtu: 08:00 - 15:00</p>
                    <p>Minggu: Libur</p>
                </div>
            </div>
            <div class="row copyright">
                <div class="col-12 text-center">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> Universitas Tangerang Raya. Hak Cipta Dilindungi.</p>
                    <p class="mb-0">Dikembangkan oleh: Tim Pengembangan Sistem Perpustakaan UTR</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
        
        // PERBAIKAN: Pastikan link login berfungsi
        document.querySelectorAll('a[href="login.php"]').forEach(link => {
            link.addEventListener('click', function(e) {
                console.log('Redirecting to login.php');
                // Tidak ada e.preventDefault() agar link tetap berfungsi
            });
        });
        
        // Debug: Cek apakah link login berfungsi
        console.log('Total login links:', document.querySelectorAll('a[href="login.php"]').length);
    </script>
</body>
</html>