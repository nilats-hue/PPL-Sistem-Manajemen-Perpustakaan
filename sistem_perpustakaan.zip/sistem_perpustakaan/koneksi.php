<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// DEBUG: Tampilkan error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Konfigurasi database
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sistem_perpustakaan'; // PASTIKAN INI SAMA DENGAN DI PHPMyAdmin

// Membuat koneksi
$koneksi = mysqli_connect($host, $username, $password, $database);

// Cek koneksi
if (!$koneksi) {
    // Coba koneksi tanpa database dulu
    $koneksi_temp = mysqli_connect($host, $username, $password);
    if ($koneksi_temp) {
        // Cek apakah database ada
        $check_db = mysqli_select_db($koneksi_temp, $database);
        if (!$check_db) {
            die("Database '$database' tidak ditemukan. Silakan buat database di PHPMyAdmin.");
        }
        mysqli_close($koneksi_temp);
    }
    die("Koneksi database gagal: " . mysqli_connect_error());
}

echo "<!-- Database connected successfully -->";

// ... fungsi-fungsi lainnya tetap sama ...