<?php
session_start();

// JIKA SUDAH LOGIN, REDIRECT KE DASHBOARD
if (isset($_SESSION['user_id'])) {
    header("Location: admin/index.php");
    exit();
}

// LOGIN SEDERHANA - HARDCODED UNTUK TESTING
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // USER TESTING
    $users = [
        'admin' => ['password' => 'admin123', 'nama' => 'Administrator', 'role' => 'admin'],
        'pustakawan' => ['password' => 'admin123', 'nama' => 'Petugas Perpustakaan', 'role' => 'petugas']
    ];
    
    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = $username;
        $_SESSION['nama'] = $users[$username]['nama'];
        $_SESSION['role'] = $users[$username]['role'];
        
        header("Location: admin/index.php");
        exit();
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Perpustakaan UTR</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #800000 0%, #600000 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: white;
            border-radius: 15px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo h1 {
            color: #800000;
            font-size: 2rem;
            margin-bottom: 5px;
        }
        
        .logo p {
            color: #666;
            font-size: 0.9rem;
        }
        
        .error {
            background: #ffeaea;
            color: #d32f2f;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            border: 1px solid #ffcdd2;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }
        
        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        input:focus {
            border-color: #800000;
            outline: none;
            box-shadow: 0 0 0 3px rgba(128, 0, 0, 0.1);
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: #800000;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 10px;
        }
        
        .btn-login:hover {
            background: #600000;
        }
        
        .btn-login:active {
            transform: scale(0.98);
        }
        
        .test-info {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 0.85rem;
            color: #666;
        }
        
        .test-info strong {
            color: #800000;
        }
        
        .back-link {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .back-link a {
            color: #800000;
            text-decoration: none;
            font-weight: 500;
        }
        
        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <h1>📚 UTR LIBRARY</h1>
            <p>Sistem Perpustakaan Digital</p>
        </div>
        
        <?php if(isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" 
                       placeholder="Masukkan username" required autofocus>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" 
                       placeholder="Masukkan password" required>
            </div>
            
            <button type="submit" class="btn-login">LOGIN</button>
        </form>
        
        <div class="test-info">
            <p><strong>Kredensial Testing:</strong></p>
            <p>Username: <strong>admin</strong> | Password: <strong>admin123</strong></p>
            <p>Username: <strong>pustakawan</strong> | Password: <strong>admin123</strong></p>
        </div>
        
        <div class="back-link">
            <a href="index.php">← Kembali ke Beranda</a>
        </div>
    </div>
    
    <script>
        // Auto-fill untuk testing
        document.addEventListener('DOMContentLoaded', function() {
            const usernameInput = document.getElementById('username');
            const passwordInput = document.getElementById('password');
            
            // Auto-fill dengan admin
            usernameInput.value = 'admin';
            passwordInput.value = 'admin123';
            
            // Fokus ke password setelah load
            setTimeout(() => {
                passwordInput.focus();
                passwordInput.select();
            }, 100);
            
            console.log('Login form loaded successfully');
        });
    </script>
</body>
</html>